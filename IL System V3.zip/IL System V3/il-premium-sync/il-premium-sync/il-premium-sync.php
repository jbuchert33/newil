<?php
/**
 * Plugin Name: IL Premium Sync
 * Description: Synchronize prompts between WordPress and Chrome extension with premium features and Stripe integration
 * Version: 1.0.0
 * Author: Intellectual Lead
 * Text Domain: il-premium-sync
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('IL_PREMIUM_SYNC_VERSION', '1.0.0');
define('IL_PREMIUM_SYNC_PATH', plugin_dir_path(__FILE__));
define('IL_PREMIUM_SYNC_URL', plugin_dir_url(__FILE__));

// --- ROBUST AUTOLOADER CHECK ---
$autoloader_path = IL_PREMIUM_SYNC_PATH . 'vendor/autoload.php';

if (file_exists($autoloader_path)) {
    require_once $autoloader_path;
} else {
    // If the autoloader is missing, show a clear error in the admin dashboard.
    // This prevents the "invalid handler" errors.
    add_action('admin_notices', function() {
        echo '<div class="notice notice-error"><p>';
        echo '<strong>IL Premium Sync - CRITICAL ERROR:</strong> The autoloader file is missing at <code>' . esc_html($autoloader_path) . '</code>. ';
        echo 'Please run <code>composer install</code> in the plugin directory to install dependencies (like the Stripe SDK). The plugin will not function correctly until this is resolved.';
        echo '</p></div>';
    });
    // Stop the plugin from loading further to prevent fatal errors.
    return;
}
// --- END AUTOLOADER CHECK ---



// Include required files
require_once IL_PREMIUM_SYNC_PATH . 'includes/class-il-api-auth.php';
require_once IL_PREMIUM_SYNC_PATH . 'includes/class-il-api-prompts.php';
require_once IL_PREMIUM_SYNC_PATH . 'includes/class-il-api-sync.php';
require_once IL_PREMIUM_SYNC_PATH . 'includes/class-il-stripe-payments.php';
require_once IL_PREMIUM_SYNC_PATH . 'includes/class-il-api-payments.php';
require_once IL_PREMIUM_SYNC_PATH . 'includes/class-il-pricing-assets.php';

// Main plugin class
class IL_Premium_Sync {
    
    /**
     * Constructor
     */
    public function __construct() {
        // Initialize hooks
        add_action('init', array($this, 'init'));
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        
        // Activation and deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Initialize Stripe payments
        new IL_Stripe_Payments();
        
        // Initialize pricing page assets
        new IL_Pricing_Assets();
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Register premium_member role if it doesn't exist
        if (!get_role('premium_member')) {
            add_role('premium_member', 'Premium Member', array(
                'read' => true,
                'access_premium_content' => true
            ));
        }
    }

    /**
     * Global REST API Error and Exception Handler.
     * This is the definitive fix to catch fatal errors and return clean JSON.
     */
    public static function log_and_handle_rest_errors($served, $result, $request, $server) {
        // Only act on our plugin's namespace
        if (strpos($request->get_route(), 'il-sync/v1') !== false) {
            set_exception_handler(function($exception) {
                error_log('[IL FATAL EXCEPTION] ' . $exception->getMessage() . ' in ' . $exception->getFile() . ':' . $exception->getLine());
                wp_send_json(array(
                    'success' => false,
                    'code' => 'fatal_exception',
                    'message' => 'A server exception occurred: ' . $exception->getMessage(),
                    'data' => array('status' => 500)
                ), 500);
            });

            set_error_handler(function($errno, $errstr, $errfile, $errline) {
                if (!(error_reporting() & $errno)) {
                    return false;
                }
                error_log("[IL FATAL ERROR] $errstr in $errfile:$errline");
                wp_send_json(array(
                    'success' => false,
                    'code' => 'fatal_error',
                    'message' => "A server error occurred: $errstr",
                    'data' => array('status' => 500, 'file' => "$errfile:$errline")
                ), 500);
                return true;
            }, E_ALL);
        }
        return $served;
    }
    
    /**
     * Register REST API routes
     */
    public function register_rest_routes() {
        // DEFINITIVE FIX: Add the global error handler to all our API routes.
        add_filter('rest_pre_serve_request', array('IL_Premium_Sync', 'log_and_handle_rest_errors'), 10, 4);

        // Auth endpoints
        register_rest_route('il-sync/v1', '/auth/login', array(
            'methods' => 'POST',
            'callback' => array('IL_API_Auth', 'login'),
            'permission_callback' => '__return_true'
        ));
		
		register_rest_route('il-sync/v1', '/auth/google', array(
			'methods' => 'POST',
			// THIS LINE MUST BE CHANGED to call the method on the class
			'callback' => array('IL_API_Auth', 'handle_google_login_for_extension'),
			'permission_callback' => '__return_true'
		));
        
        register_rest_route('il-sync/v1', '/auth/verify', array(
            'methods' => 'GET',
            'callback' => array('IL_API_Auth', 'verify'),
            'permission_callback' => array('IL_API_Auth', 'check_permission')
        ));
        
        // Prompts endpoints
        register_rest_route('il-sync/v1', '/prompts', array(
            'methods' => 'GET',
            'callback' => array('IL_API_Prompts', 'get_prompts'),
            'permission_callback' => array('IL_API_Auth', 'check_permission')
        ));
        
        register_rest_route('il-sync/v1', '/prompts', array(
            'methods' => 'POST',
            'callback' => array('IL_API_Prompts', 'save_prompt'),
            'permission_callback' => array('IL_API_Auth', 'check_permission')
        ));
        
        register_rest_route('il-sync/v1', '/prompts/(?P<id>[a-zA-Z0-9-]+)', array(
            'methods' => 'DELETE',
            'callback' => array('IL_API_Prompts', 'delete_prompt'),
            'permission_callback' => array('IL_API_Auth', 'check_permission')
        ));
        
        // Sync endpoints
        register_rest_route('il-sync/v1', '/sync/full', array(
            'methods' => 'POST',
            'callback' => array('IL_API_Sync', 'full_sync'),
            'permission_callback' => array('IL_API_Auth', 'check_permission')
        ));
        
        // Plan status endpoint
        register_rest_route('il-sync/v1', '/plans/status', array(
            'methods' => 'GET',
            'callback' => array('IL_API_Prompts', 'get_plan_status'),
            'permission_callback' => array('IL_API_Auth', 'check_permission')
        ));
        
        // Payment status endpoint
        register_rest_route('il-sync/v1', '/payments/status', array(
            'methods' => 'GET',
            'callback' => array('IL_API_Payments', 'get_payment_status'),
            'permission_callback' => array('IL_API_Auth', 'check_permission')
        ));
        
        // Payment status endpoint with better error handling
        register_rest_route('il-sync/v1', '/payments/status-debug', array(
            'methods' => 'GET',
            'callback' => array('IL_API_Payments', 'get_payment_status_debug'),
            'permission_callback' => '__return_true'
        ));
        
        // Payment status by email (for post-payment sync)
        register_rest_route('il-sync/v1', '/payments/status-by-email', array(
            'methods' => 'POST',
            'callback' => array('IL_API_Payments', 'get_payment_status_by_email'),
            'permission_callback' => '__return_true'
        ));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_options_page(
            'IL Premium Sync Settings',
            'IL Premium Sync',
            'manage_options',
            'il-premium-sync',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('il_premium_sync', 'il_premium_sync_settings');
        
        add_settings_section(
            'il_premium_sync_general',
            'General Settings',
            array($this, 'render_general_section'),
            'il_premium_sync'
        );
        
        add_settings_field(
            'jwt_secret_key',
            'JWT Secret Key',
            array($this, 'render_jwt_secret_field'),
            'il_premium_sync',
            'il_premium_sync_general'
        );
        
        add_settings_field(
            'free_prompt_limit',
            'Free Plan Prompt Limit',
            array($this, 'render_free_limit_field'),
            'il_premium_sync',
            'il_premium_sync_general'
        );
        
        add_settings_section(
            'il_premium_sync_stripe',
            'Stripe Settings',
            array($this, 'render_stripe_section'),
            'il_premium_sync'
        );
        
        add_settings_field(
            'stripe_secret_key',
            'Stripe Secret Key',
            array($this, 'render_stripe_secret_field'),
            'il_premium_sync',
            'il_premium_sync_stripe'
        );
        
        add_settings_field(
            'stripe_publishable_key',
            'Stripe Publishable Key',
            array($this, 'render_stripe_publishable_field'),
            'il_premium_sync',
            'il_premium_sync_stripe'
        );
        
        add_settings_field(
            'stripe_webhook_secret',
            'Stripe Webhook Secret',
            array($this, 'render_stripe_webhook_field'),
            'il_premium_sync',
            'il_premium_sync_stripe'
        );
        
        add_settings_field(
            'stripe_monthly_price_id',
            'Monthly Plan Price ID',
            array($this, 'render_stripe_monthly_price_field'),
            'il_premium_sync',
            'il_premium_sync_stripe'
        );
        
        add_settings_field(
            'stripe_yearly_price_id',
            'Yearly Plan Price ID',
            array($this, 'render_stripe_yearly_price_field'),
            'il_premium_sync',
            'il_premium_sync_stripe'
        );
        
        add_settings_field(
            'stripe_price_ids',
            'Stripe Price IDs (Legacy)',
            array($this, 'render_stripe_price_ids_field'),
            'il_premium_sync',
            'il_premium_sync_stripe'
        );
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>IL Premium Sync Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('il_premium_sync');
                do_settings_sections('il_premium_sync');
                submit_button();
                ?>
            </form>
            
            <hr>
            
            <h2>Sync Log</h2>
            <?php $this->render_sync_log(); ?>
            
            <h2>Payment Log</h2>
            <?php $this->render_payment_log(); ?>
            
            <h2>Premium Users</h2>
            <?php $this->render_premium_users(); ?>
        </div>
        <?php
    }
    
    /**
     * Render general section
     */
    public function render_general_section() {
        echo '<p>Configure general settings for the IL Premium Sync plugin.</p>';
    }
    
    /**
     * Render JWT secret field
     */
    public function render_jwt_secret_field() {
        $options = get_option('il_premium_sync_settings');
        $jwt_secret = isset($options['jwt_secret_key']) ? $options['jwt_secret_key'] : '';
        
        if (empty($jwt_secret)) {
            $jwt_secret = bin2hex(random_bytes(32));
        }
        
        echo '<input type="text" id="jwt_secret_key" name="il_premium_sync_settings[jwt_secret_key]" value="' . esc_attr($jwt_secret) . '" class="regular-text">';
        echo '<p class="description">Secret key used for JWT authentication. Keep this secure.</p>';
    }
    
    /**
     * Render free limit field
     */
    public function render_free_limit_field() {
        $options = get_option('il_premium_sync_settings');
        $free_limit = isset($options['free_prompt_limit']) ? $options['free_prompt_limit'] : 30;
        
        echo '<input type="number" id="free_prompt_limit" name="il_premium_sync_settings[free_prompt_limit]" value="' . esc_attr($free_limit) . '" class="small-text">';
        echo '<p class="description">Maximum number of prompts allowed for free users.</p>';
    }
    
    /**
     * Render Stripe section
     */
    public function render_stripe_section() {
        echo '<p>Configure Stripe payment integration settings.</p>';
    }
    
    /**
     * Render Stripe secret field
     */
    public function render_stripe_secret_field() {
        $options = get_option('il_premium_sync_settings');
        $stripe_secret = isset($options['stripe_secret_key']) ? $options['stripe_secret_key'] : '';
        
        echo '<input type="text" id="stripe_secret_key" name="il_premium_sync_settings[stripe_secret_key]" value="' . esc_attr($stripe_secret) . '" class="regular-text">';
        echo '<p class="description">Stripe Secret Key (starts with sk_).</p>';
    }
    
    /**
     * Render Stripe publishable field
     */
    public function render_stripe_publishable_field() {
        $options = get_option('il_premium_sync_settings');
        $stripe_publishable = isset($options['stripe_publishable_key']) ? $options['stripe_publishable_key'] : '';
        
        echo '<input type="text" id="stripe_publishable_key" name="il_premium_sync_settings[stripe_publishable_key]" value="' . esc_attr($stripe_publishable) . '" class="regular-text">';
        echo '<p class="description">Stripe Publishable Key (starts with pk_).</p>';
    }
    
    /**
     * Render Stripe webhook field
     */
    public function render_stripe_webhook_field() {
        $options = get_option('il_premium_sync_settings');
        $webhook_secret = isset($options['stripe_webhook_secret']) ? $options['stripe_webhook_secret'] : '';
        
        echo '<input type="text" id="stripe_webhook_secret" name="il_premium_sync_settings[stripe_webhook_secret]" value="' . esc_attr($webhook_secret) . '" class="regular-text">';
        echo '<p class="description">Stripe Webhook Secret (starts with whsec_).</p>';
        echo '<p class="description">Webhook URL: <code>' . rest_url('il-sync/v1/stripe/webhook') . '</code></p>';
    }
    
    /**
     * Render Monthly Plan Price ID field
     */
    public function render_stripe_monthly_price_field() {
        $options = get_option('il_premium_sync_settings');
        $monthly_price_id = isset($options['stripe_monthly_price_id']) ? $options['stripe_monthly_price_id'] : '';
        
        echo '<input type="text" id="stripe_monthly_price_id" name="il_premium_sync_settings[stripe_monthly_price_id]" value="' . esc_attr($monthly_price_id) . '" class="regular-text">';
        echo '<p class="description">Stripe Price ID for monthly subscription (starts with price_). Create this in your Stripe Dashboard → Products.</p>';
    }
    
    /**
     * Render Yearly Plan Price ID field
     */
    public function render_stripe_yearly_price_field() {
        $options = get_option('il_premium_sync_settings');
        $yearly_price_id = isset($options['stripe_yearly_price_id']) ? $options['stripe_yearly_price_id'] : '';
        
        echo '<input type="text" id="stripe_yearly_price_id" name="il_premium_sync_settings[stripe_yearly_price_id]" value="' . esc_attr($yearly_price_id) . '" class="regular-text">';
        echo '<p class="description">Stripe Price ID for yearly subscription (starts with price_). Create this in your Stripe Dashboard → Products.</p>';
    }
    
    /**
     * Render Stripe price IDs field
     */
    public function render_stripe_price_ids_field() {
        $options = get_option('il_premium_sync_settings');
        $price_ids = isset($options['stripe_price_ids']) ? $options['stripe_price_ids'] : array(
            'monthly' => '',
            'yearly' => ''
        );
        
        echo '<div class="stripe-price-ids">';
        echo '<div class="price-id-row">';
        echo '<label>Monthly Plan: </label>';
        echo '<input type="text" name="il_premium_sync_settings[stripe_price_ids][monthly]" value="' . esc_attr($price_ids['monthly']) . '" class="regular-text">';
        echo '</div>';
        
        echo '<div class="price-id-row">';
        echo '<label>Yearly Plan: </label>';
        echo '<input type="text" name="il_premium_sync_settings[stripe_price_ids][yearly]" value="' . esc_attr($price_ids['yearly']) . '" class="regular-text">';
        echo '</div>';
        echo '</div>';
        
        echo '<p class="description">Stripe Price IDs for subscription plans (starts with price_).</p>';
    }
    
    /**
     * Render sync log
     */
    public function render_sync_log() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'il_sync_log';
        
        $logs = $wpdb->get_results(
            "SELECT * FROM $table_name ORDER BY timestamp DESC LIMIT 20"
        );
        
        if (empty($logs)) {
            echo '<p>No sync logs found.</p>';
            return;
        }
        
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>User</th><th>Action</th><th>Prompt ID</th><th>Data</th><th>Timestamp</th></tr></thead>';
        echo '<tbody>';
        
        foreach ($logs as $log) {
            $user = get_user_by('id', $log->user_id);
            $username = $user ? $user->user_login : 'Unknown';
            
            echo '<tr>';
            echo '<td>' . esc_html($username) . '</td>';
            echo '<td>' . esc_html($log->action) . '</td>';
            echo '<td>' . esc_html($log->prompt_id ?? 'N/A') . '</td>';
            echo '<td><pre style="max-height: 100px; overflow: auto;">' . esc_html($log->data) . '</pre></td>';
            echo '<td>' . esc_html($log->timestamp) . '</td>';
            echo '</tr>';
        }
        
        echo '</tbody></table>';
    }
    
    /**
     * Render payment log
     */
    public function render_payment_log() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'il_payment_log';
        
        $logs = $wpdb->get_results(
            "SELECT * FROM $table_name ORDER BY timestamp DESC LIMIT 20"
        );
        
        if (empty($logs)) {
            echo '<p>No payment logs found.</p>';
            return;
        }
        
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>User</th><th>Event</th><th>Data</th><th>Timestamp</th></tr></thead>';
        echo '<tbody>';
        
        foreach ($logs as $log) {
            $user = get_user_by('id', $log->user_id);
            $username = $user ? $user->user_login : 'Unknown';
            
            echo '<tr>';
            echo '<td>' . esc_html($username) . '</td>';
            echo '<td>' . esc_html($log->event_type) . '</td>';
            echo '<td><pre style="max-height: 100px; overflow: auto;">' . esc_html($log->data) . '</pre></td>';
            echo '<td>' . esc_html($log->timestamp) . '</td>';
            echo '</tr>';
        }
        
        echo '</tbody></table>';
    }
    
    /**
     * Render premium users
     */
    public function render_premium_users() {
        // Get users with premium_member role
        $premium_users = get_users(array(
            'role' => 'premium_member'
        ));
        
        if (empty($premium_users)) {
            echo '<p>No premium users found.</p>';
            return;
        }
        
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>User</th><th>Email</th><th>Status</th><th>Subscription ID</th><th>Last Payment</th><th>Activated Date</th><th>Actions</th></tr></thead>';
        echo '<tbody>';
        
        foreach ($premium_users as $user) {
            $premium_status = get_user_meta($user->ID, 'il_premium_plan_status', true);
            $subscription_id = get_user_meta($user->ID, 'il_stripe_subscription_id', true);
            $last_payment = get_user_meta($user->ID, 'il_premium_plan_last_payment', true);
            $activated_date = get_user_meta($user->ID, 'il_premium_plan_activated', true);
            
            echo '<tr>';
            echo '<td>' . esc_html($user->user_login) . '</td>';
            echo '<td>' . esc_html($user->user_email) . '</td>';
            echo '<td>' . esc_html($premium_status ?: 'active') . '</td>';
            echo '<td>' . esc_html($subscription_id ?: 'N/A') . '</td>';
            echo '<td>' . esc_html($last_payment ? date('Y-m-d H:i:s', strtotime($last_payment)) : 'N/A') . '</td>';
            echo '<td>' . esc_html($activated_date ? date('Y-m-d H:i:s', strtotime($activated_date)) : 'N/A') . '</td>';
            echo '<td>';
            echo '<a href="' . admin_url('user-edit.php?user_id=' . $user->ID) . '" class="button button-small">Edit User</a> ';
            echo '<button class="button button-small button-link-delete revoke-premium" data-user-id="' . $user->ID . '">Revoke Premium</button>';
            echo '</td>';
            echo '</tr>';
        }
        
        echo '</tbody></table>';
        
        // Add JavaScript for revoke premium button
        ?>
        <script>
        jQuery(document).ready(function($) {
            $('.revoke-premium').on('click', function() {
                if (confirm('Are you sure you want to revoke premium access for this user?')) {
                    var userId = $(this).data('user-id');
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'il_revoke_premium',
                            user_id: userId,
                            nonce: '<?php echo wp_create_nonce('il-revoke-premium'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                alert('Premium access revoked successfully.');
                                location.reload();
                            } else {
                                alert('Error: ' + response.data.message);
                            }
                        },
                        error: function() {
                            alert('An error occurred. Please try again.');
                        }
                    });
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * Enqueue admin scripts
     */
    public function admin_enqueue_scripts($hook) {
        if ($hook !== 'settings_page_il-premium-sync') {
            return;
        }
        
        wp_enqueue_style('il-premium-sync-admin', IL_PREMIUM_SYNC_URL . 'assets/css/admin.css', array(), IL_PREMIUM_SYNC_VERSION);
        wp_enqueue_script('il-premium-sync-admin', IL_PREMIUM_SYNC_URL . 'assets/js/admin.js', array('jquery'), IL_PREMIUM_SYNC_VERSION, true);
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create database tables
        $this->create_tables();
        
        // Set default settings
        $default_settings = array(
            'jwt_secret_key' => bin2hex(random_bytes(32)),
            'free_prompt_limit' => 30,
            'stripe_price_ids' => array(
                'monthly' => '',
                'yearly' => ''
            )
        );
        
        $existing_settings = get_option('il_premium_sync_settings');
        
        if (!$existing_settings) {
            update_option('il_premium_sync_settings', $default_settings);
        }
        
        // Create premium_member role
        add_role('premium_member', 'Premium Member', array(
            'read' => true,
            'access_premium_content' => true
        ));
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Create database tables
     */
    private function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Create sync log table
        $sync_log_table = $wpdb->prefix . 'il_sync_log';
        
        $sync_log_sql = "CREATE TABLE $sync_log_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            action varchar(50) NOT NULL,
            prompt_id varchar(50),
            data longtext,
            timestamp datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY action (action),
            KEY timestamp (timestamp)
        ) $charset_collate;";
        
        // Create payment log table
        IL_Stripe_Payments::create_payment_log_table();
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sync_log_sql);
    }
}

// Initialize the plugin
$il_premium_sync = new IL_Premium_Sync();

// Add AJAX handler for revoking premium access
add_action('wp_ajax_il_revoke_premium', 'il_revoke_premium_callback');

function il_revoke_premium_callback() {
    // Check nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'il-revoke-premium')) {
        wp_send_json_error(array('message' => 'Invalid nonce'));
        exit;
    }
    
    // Check if user has permission
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Permission denied'));
        exit;
    }
    
    // Get user ID
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
    
    if (!$user_id) {
        wp_send_json_error(array('message' => 'Invalid user ID'));
        exit;
    }
    
    // Update user meta
    update_user_meta($user_id, 'il_premium_plan', 'inactive');
    update_user_meta($user_id, 'il_premium_plan_status', 'canceled');
    update_user_meta($user_id, 'il_premium_plan_canceled', current_time('mysql'));
    
    // Remove premium role
    $user = get_user_by('id', $user_id);
    if ($user) {
        $user->remove_role('premium_member');
    }
    
    // Log the event
    global $wpdb;
    $table_name = $wpdb->prefix . 'il_payment_log';
    
    $wpdb->insert(
        $table_name,
        array(
            'user_id' => $user_id,
            'event_type' => 'premium_revoked',
            'data' => json_encode(array(
                'revoked_by' => get_current_user_id(),
                'timestamp' => current_time('c')
            )),
            'timestamp' => current_time('mysql')
        ),
        array('%d', '%s', '%s', '%s')
    );
    
    wp_send_json_success(array('message' => 'Premium access revoked successfully'));
    exit;
}