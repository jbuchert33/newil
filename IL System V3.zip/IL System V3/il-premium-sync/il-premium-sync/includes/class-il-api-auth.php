<?php
/**
 * API Authentication Class
 * Handles JWT authentication for the API
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class IL_API_Auth {
    
    /**
     * Login user and generate JWT token
     */
    public static function login($request) {
        $params = $request->get_params();
        
        if (empty($params['username']) || empty($params['password'])) {
            return new WP_Error('missing_credentials', 'Username and password are required', array('status' => 400));
        }
        
        $user = wp_authenticate($params['username'], $params['password']);
        
        if (is_wp_error($user)) {
            return new WP_Error('invalid_credentials', 'Invalid username or password', array('status' => 401));
        }
        
        $token = self::generate_token($user);
        
        return rest_ensure_response(array(
            'success' => true,
            'token' => $token,
            'user' => array(
                'id' => $user->ID,
                'username' => $user->user_login,
                'email' => $user->user_email,
                'display_name' => $user->display_name
            )
        ));
    }
    
    /**
     * Handle login via Google OAuth token from the extension.
     * @param WP_REST_Request $request The request object.
     * @return WP_REST_Response|WP_Error
     */
    // THIS FUNCTION IS NOW CORRECTLY DEFINED AS A STATIC METHOD
    public static function handle_google_login_for_extension($request) {
        $params = $request->get_json_params();
        $google_access_token = isset($params['token']) ? sanitize_text_field($params['token']) : '';

        if (empty($google_access_token)) {
            return new WP_Error('no_token', 'Google access token not provided.', array('status' => 400));
        }

        $google_response = wp_remote_get("https://www.googleapis.com/oauth2/v3/tokeninfo?access_token={$google_access_token}");

        if (is_wp_error($google_response)) {
            return new WP_Error('google_error', 'Failed to connect to Google for verification.', array('status' => 500));
        }

        $response_code = wp_remote_retrieve_response_code($google_response);
        $user_data = json_decode(wp_remote_retrieve_body($google_response), true);

        if ($response_code !== 200 || !isset($user_data['email'])) {
            return new WP_Error('invalid_token', 'Invalid or expired Google token.', array('status' => 401));
        }
        
        $email = sanitize_email($user_data['email']);
        $user = get_user_by('email', $email);

        if (!$user) {
            if (!get_option('users_can_register')) {
                return new WP_Error('registration_disabled', 'User registration is currently disabled.', array('status' => 403));
            }

            $password = wp_generate_password(16, true);
            $username = explode('@', $email)[0] . '_' . time();
            $user_id = wp_create_user($username, $password, $email);

            if (is_wp_error($user_id)) {
                return new WP_Error('user_creation_failed', $user_id->get_error_message(), array('status' => 500));
            }
            
            wp_update_user(array(
                'ID' => $user_id,
                'display_name' => sanitize_text_field($user_data['name'] ?? ''),
                'first_name' => sanitize_text_field($user_data['given_name'] ?? ''),
                'last_name' => sanitize_text_field($user_data['family_name'] ?? '')
            ));

            wp_new_user_notification($user_id, null, 'both');
            do_action('user_register', $user_id);
            $user = get_user_by('id', $user_id);
        }
        
        $token = self::generate_token($user);

        return new WP_REST_Response(array(
            'success'   => true,
            'token'     => $token,
            'user'      => array(
                'email' => $user->user_email,
                'id'    => $user->ID
            )
        ), 200);
    }
    
    /**
     * Verify JWT token
     */
    public static function verify_token($request) {
        $user_id = self::validate_token($request);
        
        if (is_wp_error($user_id)) {
            return $user_id;
        }
        
        $user = get_user_by('id', $user_id);
        
        if (!$user) {
            return new WP_Error('user_not_found', 'User not found', array('status' => 404));
        }
        
        return rest_ensure_response(array(
            'success' => true,
            'user' => array(
                'id' => $user->ID,
                'username' => $user->user_login,
                'email' => $user->user_email,
                'display_name' => $user->display_name
            )
        ));
    }
    
    /**
     * Check permission for protected routes
     */
    public static function check_permission($request) {
        $user_id = self::validate_token($request);
        
        if (is_wp_error($user_id)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Validate JWT token from Authorization header
     */
    public static function validate_token($request) {
        $auth_header = $request->get_header('Authorization');
        
        if (!$auth_header || strpos($auth_header, 'Bearer ') !== 0) {
            return new WP_Error('invalid_token', 'Authorization header missing or invalid', array('status' => 401));
        }
        
        $token = substr($auth_header, 7);
        
        try {
            $decoded = self::decode_token($token);
            
            if (empty($decoded->user_id)) {
                return new WP_Error('invalid_token', 'Invalid token payload', array('status' => 401));
            }
            
            return $decoded->user_id;
            
        } catch (Exception $e) {
            return new WP_Error('invalid_token', $e->getMessage(), array('status' => 401));
        }
    }
    
    /**
     * Generate JWT token for user
     */
    private static function generate_token($user) {
        $settings = get_option('il_premium_sync_settings');
        $secret = $settings['jwt_secret_key'];
        $expiry = $settings['token_expiry'] ?? (24 * 60 * 60); // Default 24 hours
        
        $issued_at = time();
        $expiration = $issued_at + $expiry;
        
        $payload = array(
            'iss' => get_site_url(),
            'iat' => $issued_at,
            'exp' => $expiration,
            'user_id' => $user->ID
        );
        
        // Create token header
        $header = base64_encode(json_encode(array(
            'alg' => 'HS256',
            'typ' => 'JWT'
        )));
        
        // Create token payload
        $payload = base64_encode(json_encode($payload));
        
        // Create signature
        $signature = base64_encode(hash_hmac('sha256', "$header.$payload", $secret, true));
        
        // Create JWT token
        return "$header.$payload.$signature";
    }
    
    /**
     * Decode JWT token
     */
    private static function decode_token($token) {
        $settings = get_option('il_premium_sync_settings');
        $secret = $settings['jwt_secret_key'];
        
        $token_parts = explode('.', $token);
        
        if (count($token_parts) !== 3) {
            throw new Exception('Invalid token format');
        }
        
        list($header, $payload, $signature) = $token_parts;
        
        // Verify signature
        $expected_signature = base64_encode(hash_hmac('sha256', "$header.$payload", $secret, true));
        
        if (!hash_equals($expected_signature, $signature)) {
            throw new Exception('Invalid token signature');
        }
        
        // Decode payload
        $payload_data = json_decode(base64_decode($payload));
        
        if (!$payload_data) {
            throw new Exception('Invalid token payload');
        }
        
        // Check expiration
        if (isset($payload_data->exp) && $payload_data->exp < time()) {
            throw new Exception('Token expired');
        }
        
        return $payload_data;
    }
}

