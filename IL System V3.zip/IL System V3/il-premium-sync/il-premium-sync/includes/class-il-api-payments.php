<?php
/**
 * API Payments Class — patched 2025‑06‑17
 * Handles payment status synchronisation between WordPress, Stripe and the browser‑extension.
 *
 *  ✅ Accepts either an **e‑mail** or a **Stripe Checkout Session‑ID** when the
 *     extension calls the `/payments/status-by-email` endpoint after Checkout.
 *  ✅ Gracefully resolves placeholder strings such as
 *     `CHECKOUT_SESSION_CUSTOMER_EMAIL` that Stripe cannot substitute.
 *  ✅ Keeps the original 200‑line API surface intact: no breaking changes for
 *     the extension or other plugins.
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class IL_API_Payments {

    /* --------------------------------------------------------------------- */
    /*  PUBLIC ENDPOINTS                                                     */
    /* --------------------------------------------------------------------- */

    /**
     * Auth‑protected: return the authenticated user’s payment status.
     */
    public static function get_payment_status( $request ) {
        $user_id = IL_API_Auth::validate_token( $request );
        if ( is_wp_error( $user_id ) ) {
            return $user_id;
        }
        return rest_ensure_response( self::get_user_payment_status( $user_id ) );
    }

    /**
     * Public: called from the extension right after a successful Checkout.
     *
     * Accepts POST parameters:
     *   • `email`       (string) – preferred.
     *   • `session_id`  (string) – fallback when the e‑mail placeholder leaks
     *                              through the Success URL.
     *
     * Example request body (JSON):
     *   { "email": "user@example.com" }
     *   { "session_id": "cs_test_123" }
     */
    /**
 *  POST  /payments/status-by-email
 *  Accepts either:
 *    • email       (preferred)
 *    • session_id  (Stripe Checkout ID) – if the e-mail isn’t available
 * The Chrome extension now also sends the user’s Bearer token, which we can
 * fall back to if *both* e-mail and session-ID are missing/invalid.
 */
	public static function get_payment_status_by_email( WP_REST_Request $req ) {

		$email      = trim( $req->get_param( 'email' ) ?? '' );
		$session_id = trim( $req->get_param( 'session_id' ) ?? '' );

		// ---------- 1. Resolve the real e-mail if we only have a session-ID ----------
		if ( ! is_email( $email ) && $session_id ) {
			try {
				// ==========================================================
				// FIX #1: ADD THIS BLOCK TO LOAD THE STRIPE LIBRARY
				// ==========================================================
				if (!class_exists('\Stripe\Stripe')) {
					$stripe_init_file = IL_PREMIUM_SYNC_PATH . 'vendor/stripe/init.php';
					if (file_exists($stripe_init_file)) {
						require_once $stripe_init_file;
					} else {
						// This will now throw a clear, controlled error
						return new WP_Error('stripe_sdk_missing', 'Stripe PHP library not found in plugin vendor directory.', ['status' => 500]);
					}
				}
				// ==========================================================
				
				// FIX #2 is applied to the line below
				$settings = get_option('il_premium_sync_settings');
				$stripe_secret = $settings['stripe_secret_key'] ?? '';
				if (empty($stripe_secret)) {
					return new WP_Error('stripe_key_missing', 'Stripe Secret Key is not configured in WordPress.', ['status' => 500]);
				}
				\Stripe\Stripe::setApiKey( $stripe_secret ); // <-- Use the correct variable
				// ==========================================================

				$session = \Stripe\Checkout\Session::retrieve( $session_id );
				$email   = $session->customer_details->email ?? '';
			} catch ( \Throwable $e ) {
				// This will now catch the errors from above as well
				return new WP_Error( 'stripe_error', $e->getMessage(), [ 'status' => 502 ] );
			}
		}

		// ---------- 2. If the extension passed a Bearer token, ignore e-mail entirely ----------
		if ( ! is_email( $email ) && ( $user_id = IL_API_Auth::validate_token( $req ) ) && ! is_wp_error( $user_id ) ) {
			$user = get_user_by( 'id', $user_id );
			$email = $user ? $user->user_email : '';
		}

		// ---------- 3. Final sanity-checks ----------
		if ( ! is_email( $email ) ) {
			return new WP_Error( 'invalid_email', 'Unable to resolve a valid e-mail address', [ 'status' => 400 ] );
		}
		$user = get_user_by( 'email', $email );
		if ( ! $user ) {
			return new WP_Error( 'user_not_found', 'No WordPress user matches this e-mail', [ 'status' => 404 ] );
		}

		// ---------- 4. Build and return the familiar payment-status payload ----------
		$status                 = self::get_user_payment_status( $user->ID );
		$status['user_info']    = [ 'id' => $user->ID, 'email' => $user->user_email ];
		$status['success']      = true;

		// CORS headers for the extension
		add_filter( 'rest_pre_serve_request', function ( $served ) {
			header( 'Access-Control-Allow-Origin: *' );
			header( 'Access-Control-Allow-Headers: Content-Type, Authorization' );
			return $served;
		} );

		return rest_ensure_response( $status );
	}


    /* --------------------------------------------------------------------- */
    /*  INTERNAL HELPERS                                                     */
    /* --------------------------------------------------------------------- */

    /**
     * Assemble the full payment status array for a given WP user.
     */
    public static function get_user_payment_status( $user_id ) {
        $premium_status  = get_user_meta( $user_id, 'il_premium_plan', true );
        $plan_status     = get_user_meta( $user_id, 'il_premium_plan_status', true );
        $subscription_id = get_user_meta( $user_id, 'il_stripe_subscription_id', true );
        $last_payment    = get_user_meta( $user_id, 'il_premium_plan_last_payment', true );
        $activated_date  = get_user_meta( $user_id, 'il_premium_plan_activated', true );

        // Prompt count (free‑tier limit enforcement).
        $saved_prompts   = get_user_meta( $user_id, 'il_user_saved_prompts_structured', true );
        $current_count   = 0;
        if ( is_array( $saved_prompts ) ) {
            foreach ( $saved_prompts as $pd ) {
                if ( empty( $pd['deleted'] ) ) {
                    $current_count++;
                }
            }
        }
        $settings   = get_option( 'il_premium_sync_settings' );
        $free_limit = $settings['free_prompt_limit'] ?? 30;

        // Role check.
        $user_obj        = get_user_by( 'id', $user_id );
        $has_premium_role = $user_obj && in_array( 'premium_member', $user_obj->roles, true );
        $is_premium       = ( 'active' === $premium_status || $has_premium_role );

        return [
            'isPremium'    => $is_premium,
            'planType'     => $is_premium ? 'premium' : 'free',
            'planStatus'   => $plan_status ?: ( $is_premium ? 'active' : 'free' ),
            'promptLimit'  => $is_premium ? -1 : $free_limit,
            'currentCount' => $current_count,
            'canSave'      => $is_premium || $current_count < $free_limit,
            'subscription' => [
                'id'            => $subscription_id ?: null,
                'lastPayment'   => $last_payment   ? date( 'c', strtotime( $last_payment ) )   : null,
                'activatedDate' => $activated_date ? date( 'c', strtotime( $activated_date ) ) : null,
            ],
            'features' => [
                'unlimitedPrompts' => $is_premium,
                'premiumLibrary'   => $is_premium,
                'advancedSync'     => $is_premium,
                'aiEnhancement'    => $is_premium,
                'prioritySupport'  => $is_premium,
                'exportImport'     => $is_premium,
            ],
        ];
    }

    /* --------------------------------------------------------------------- */
    /*  UPDATE HELPERS (unchanged from original)                             */
    /* --------------------------------------------------------------------- */

    public static function update_payment_status( $user_id, $status, $subscription_id = null ) {
        error_log( 'IL Premium: Updating payment status for user ' . $user_id . ' → ' . $status );
        update_user_meta( $user_id, 'il_premium_plan',         'active' === $status ? 'active' : 'inactive' );
        update_user_meta( $user_id, 'il_premium_plan_status',  $status );
        update_user_meta( $user_id, 'il_premium_plan_last_payment', current_time( 'mysql' ) );
        if ( ! get_user_meta( $user_id, 'il_premium_plan_activated', true ) && 'active' === $status ) {
            update_user_meta( $user_id, 'il_premium_plan_activated', current_time( 'mysql' ) );
        }
        if ( $subscription_id ) {
            update_user_meta( $user_id, 'il_stripe_subscription_id', $subscription_id );
        }
        $user = get_user_by( 'id', $user_id );
        if ( $user ) {
            if ( 'active' === $status ) {
                $user->add_role( 'premium_member' );
            } else {
                $user->remove_role( 'premium_member' );
            }
        }
        self::log_payment_status_update( $user_id, $status, $subscription_id );
        return true;
    }
    
    /**
     * Log payment status update
     */
    private static function log_payment_status_update($user_id, $status, $subscription_id = null) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'il_payment_log';
        
        $wpdb->insert(
            $table_name,
            array(
                'user_id' => $user_id,
                'event_type' => 'payment_status_update',
                'data' => json_encode(array(
                    'status' => $status,
                    'subscription_id' => $subscription_id,
                    'timestamp' => current_time('c')
                )),
                'timestamp' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s')
        );
    }
    
    /**
     * Check if user can save more prompts
     */
    public static function can_save_more_prompts($user_id) {
        // Get user payment status
        $status = self::get_user_payment_status($user_id);
        
        return $status['canSave'];
    }
    
    /**
     * Get premium features for user
     */
    public static function get_premium_features($user_id) {
        // Get user payment status
        $status = self::get_user_payment_status($user_id);
        
        return $status['features'];
    }
}

