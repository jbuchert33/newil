<?php
/**
 * IL Pricing Page Assets
 * Handles loading of pricing page JavaScript and CSS
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class IL_Pricing_Assets {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_pricing_assets'));
        add_action('wp_footer', array($this, 'add_pricing_inline_script'));
    }
    
    /**
     * Enqueue pricing page assets
     */
    public function enqueue_pricing_assets() {
        // Only load on pricing pages or pages with pricing shortcode
        if ($this->is_pricing_page()) {
            // Enqueue Stripe.js
            wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/', array(), null, true);
            
            // Enqueue our pricing script
            wp_enqueue_script(
                'il-pricing-page',
                plugin_dir_url(dirname(__FILE__)) . 'assets/js/il-pricing-page.js',
                array('jquery', 'stripe-js'),
                '1.0.0',
                true
            );
            
            // Localize script with Stripe keys and settings
            $settings = get_option('il_premium_sync_settings', array());
            
            wp_localize_script('il-pricing-page', 'il_stripe_params', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'api_base_url' => home_url('/wp-json/il-sync/v1'),
                'publishable_key' => $settings['stripe_publishable_key'] ?? '',
                'nonce' => wp_create_nonce('il-stripe-nonce'),
                'login_url' => wp_login_url(get_permalink()),
                'success_url' => home_url('/premium-success'),
                'cancel_url' => home_url('/premium-cancel')
            ));
            
            // Add pricing page CSS
            wp_enqueue_style(
                'il-pricing-page',
                plugin_dir_url(dirname(__FILE__)) . 'assets/css/pricing-page.css',
                array(),
                '1.0.0'
            );
        }
    }
    
    /**
     * Add inline script for additional configuration
     */
    public function add_pricing_inline_script() {
        if ($this->is_pricing_page()) {
            ?>
            <script type="text/javascript">
                // Additional configuration for pricing page
                document.addEventListener('DOMContentLoaded', function() {
                    // Add any additional initialization here
                    console.log('IL Pricing Page: Assets loaded');
                    
                    // Handle URL parameters for success/cancel
                    const urlParams = new URLSearchParams(window.location.search);
                    
                    if (urlParams.get('payment') === 'success') {
                        // Show success message
                        setTimeout(() => {
                            if (window.ILPricing) {
                                window.ILPricing.showMessage('Paiement réussi ! Votre abonnement premium est maintenant actif.', 'success');
                            }
                        }, 1000);
                    } else if (urlParams.get('payment') === 'cancelled') {
                        // Show cancelled message
                        setTimeout(() => {
                            if (window.ILPricing) {
                                window.ILPricing.showMessage('Paiement annulé. Vous pouvez réessayer à tout moment.', 'info');
                            }
                        }, 1000);
                    }
                });
            </script>
            <?php
        }
    }
    
    /**
     * Check if current page is a pricing page
     */
    private function is_pricing_page() {
        global $post;
        
        // Check if it's a specific pricing page
        if (is_page() && $post) {
            $page_slug = $post->post_name;
            $pricing_pages = array('pricing', 'premium', 'plans', 'subscribe');
            
            if (in_array($page_slug, $pricing_pages)) {
                return true;
            }
        }
        
        // Check if page contains pricing shortcode or Elementor template
        if (is_a($post, 'WP_Post')) {
            if (has_shortcode($post->post_content, 'il_premium_checkout') ||
                has_shortcode($post->post_content, 'il_pricing_table') ||
                strpos($post->post_content, 'il-checkout-button') !== false) {
                return true;
            }
        }
        
        // Check for Elementor pricing template
        if (class_exists('\\Elementor\\Plugin')) {
            $elementor_data = get_post_meta(get_the_ID(), '_elementor_data', true);
            if (!empty($elementor_data) && strpos($elementor_data, 'il-checkout-button') !== false) {
                return true;
            }
        }
        
        return false;
    }
}

// Initialize the pricing assets class
new IL_Pricing_Assets();

