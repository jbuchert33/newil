<?php
/**
 * API Sync Class - FIXED VERSION
 * Handles synchronization between extension and WordPress with proper deletion sync
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class IL_API_Sync {
    
    /**
     * Perform full synchronization with proper deletion handling
     */
    public static function full_sync($request) {
        $user_id = IL_API_Auth::validate_token($request);
        
        if (is_wp_error($user_id)) {
            return $user_id;
        }
        
        $params = $request->get_params();
        $local_prompts = isset($params['local_prompts']) ? $params['local_prompts'] : array();
        $last_sync = isset($params['last_sync']) ? $params['last_sync'] : null;
        
        // Get server prompts (from WordPress meta)
        $server_prompts = self::get_server_prompts($user_id);
        
        // Get deletion log since last sync
        $deleted_prompts = self::get_deleted_prompts_since($user_id, $last_sync);
        
        // Merge prompts with proper deletion handling
        $merged_result = self::merge_prompts_with_deletions($local_prompts, $server_prompts, $deleted_prompts, $user_id);
        
        // Update server with any new local prompts
        self::update_server_prompts($user_id, $merged_result['final_prompts']);
        
        // Log sync activity
        self::log_sync_activity($user_id, 'full_sync', array(
            'local_count' => count($local_prompts),
            'server_count' => count($server_prompts),
            'deleted_count' => count($deleted_prompts),
            'final_count' => count($merged_result['final_prompts'])
        ));
        
        // Get updated plan status
        $plan_status = IL_API_Prompts::get_plan_status($request);
        $plan_data = $plan_status->get_data();
        
        return rest_ensure_response(array(
            'success' => true,
            'server_prompts' => $merged_result['final_prompts'],
            'prompts' => $merged_result['final_prompts'], // Alias for compatibility
            'deleted_prompts' => $deleted_prompts,
            'stats' => array(
                'local_prompts' => count($local_prompts),
                'server_prompts' => count($server_prompts),
                'deleted_prompts' => count($deleted_prompts),
                'final_prompts' => count($merged_result['final_prompts']),
                'conflicts_resolved' => $merged_result['conflicts_resolved']
            ),
            'conflicts' => $merged_result['conflicts'],
            'user_plan' => $plan_data,
            'sync_timestamp' => current_time('c')
        ));
    }
    
    /**
     * Get server prompts from WordPress meta
     */
    private static function get_server_prompts($user_id) {
        $saved_prompts_meta = get_user_meta($user_id, 'il_user_saved_prompts_structured', true);
        
        if (empty($saved_prompts_meta) || !is_array($saved_prompts_meta)) {
            return array();
        }
        
        $prompts = array();
        
        foreach ($saved_prompts_meta as $index => $prompt_data) {
            if (isset($prompt_data['text']) && !empty($prompt_data['text'])) {
                // Check if prompt is marked as deleted
                if (isset($prompt_data['deleted']) && $prompt_data['deleted']) {
                    continue; // Skip deleted prompts
                }
                
                $prompts[] = array(
                    'uuid' => isset($prompt_data['uuid']) ? $prompt_data['uuid'] : self::generate_uuid(),
                    'id' => $index,
                    'title' => isset($prompt_data['title']) ? $prompt_data['title'] : 'Untitled Prompt',
                    'content' => $prompt_data['text'],
                    'category' => isset($prompt_data['category']) ? $prompt_data['category'] : 'General',
                    'tags' => isset($prompt_data['tags']) ? $prompt_data['tags'] : '',
                    'is_favorite' => isset($prompt_data['is_favorite']) ? (bool)$prompt_data['is_favorite'] : false,
                    'favorite' => isset($prompt_data['is_favorite']) ? (bool)$prompt_data['is_favorite'] : false,
                    'source' => 'server',
                    'createdAt' => isset($prompt_data['created_at']) ? $prompt_data['created_at'] : date('c'),
                    'updatedAt' => isset($prompt_data['updated_at']) ? $prompt_data['updated_at'] : date('c')
                );
            }
        }
        
        return $prompts;
    }
    
    /**
     * Get prompts deleted since last sync
     */
    private static function get_deleted_prompts_since($user_id, $last_sync) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'il_sync_log';
        
        if (!$last_sync) {
            // If no last sync, get all deletions from the last 30 days
            $last_sync = date('Y-m-d H:i:s', strtotime('-30 days'));
        } else {
            $last_sync = date('Y-m-d H:i:s', strtotime($last_sync));
        }
        
        $deleted_prompts = $wpdb->get_results($wpdb->prepare(
            "SELECT prompt_id, data FROM $table_name 
             WHERE user_id = %d 
             AND action = 'delete_prompt' 
             AND timestamp > %s 
             ORDER BY timestamp DESC",
            $user_id,
            $last_sync
        ));
        
        $deleted_uuids = array();
        foreach ($deleted_prompts as $deletion) {
            if ($deletion->prompt_id) {
                $deleted_uuids[] = $deletion->prompt_id;
            }
        }
        
        return $deleted_uuids;
    }
    
    /**
     * Merge local and server prompts with proper deletion handling
     */
    private static function merge_prompts_with_deletions($local_prompts, $server_prompts, $deleted_prompts, $user_id) {
        $final_prompts = array();
        $conflicts = array();
        $conflicts_resolved = 0;
        $seen_uuids = array();
        
        // First, add all server prompts (they are authoritative)
        foreach ($server_prompts as $server_prompt) {
            $uuid = $server_prompt['uuid'];
            
            // Skip if this prompt was deleted
            if (in_array($uuid, $deleted_prompts)) {
                continue;
            }
            
            if (!in_array($uuid, $seen_uuids)) {
                $seen_uuids[] = $uuid;
                $final_prompts[] = $server_prompt;
            }
        }
        
        // Then, add local prompts that don't exist on server and weren't deleted
        foreach ($local_prompts as $local_prompt) {
            $uuid = isset($local_prompt['uuid']) ? $local_prompt['uuid'] : null;
            
            if (!$uuid) {
                // Generate UUID for local prompt without one
                $uuid = self::generate_uuid();
                $local_prompt['uuid'] = $uuid;
            }
            
            // Skip if this prompt was deleted
            if (in_array($uuid, $deleted_prompts)) {
                continue;
            }
            
            if (!in_array($uuid, $seen_uuids)) {
                // Check plan limits before adding new prompts
                $plan_status = self::get_user_plan_status($user_id);
                
                if ($plan_status['canSave']) {
                    $seen_uuids[] = $uuid;
                    $local_prompt['source'] = 'local';
                    $final_prompts[] = $local_prompt;
                    
                    // Save new local prompt to server
                    self::save_local_prompt_to_server($local_prompt, $user_id);
                } else {
                    $conflicts[] = array(
                        'type' => 'limit_reached',
                        'prompt' => $local_prompt,
                        'message' => 'Prompt limit reached. Upgrade to Premium for unlimited prompts.'
                    );
                }
            } else {
                // Conflict: prompt exists on both sides
                $server_version = null;
                foreach ($final_prompts as $existing_prompt) {
                    if ($existing_prompt['uuid'] === $uuid) {
                        $server_version = $existing_prompt;
                        break;
                    }
                }
                
                if ($server_version) {
                    // Check timestamps to resolve conflict
                    $local_time = strtotime($local_prompt['updatedAt'] ?? $local_prompt['createdAt'] ?? '1970-01-01');
                    $server_time = strtotime($server_version['updatedAt'] ?? $server_version['createdAt'] ?? '1970-01-01');
                    
                    if ($local_time > $server_time) {
                        // Local version is newer, update server
                        for ($i = 0; $i < count($final_prompts); $i++) {
                            if ($final_prompts[$i]['uuid'] === $uuid) {
                                $final_prompts[$i] = $local_prompt;
                                $final_prompts[$i]['source'] = 'local_newer';
                                break;
                            }
                        }
                        
                        // Update server with newer local version
                        self::save_local_prompt_to_server($local_prompt, $user_id);
                        $conflicts_resolved++;
                    }
                }
            }
        }
        
        return array(
            'final_prompts' => $final_prompts,
            'conflicts' => $conflicts,
            'conflicts_resolved' => $conflicts_resolved
        );
    }
    
    /**
     * Update server prompts (clean up deleted ones)
     */
    private static function update_server_prompts($user_id, $final_prompts) {
        $saved_prompts_meta = array();
        
        foreach ($final_prompts as $prompt) {
            $prompt_data = array(
                'text' => $prompt['content'],
                'title' => $prompt['title'] ?? 'Untitled Prompt',
                'category' => $prompt['category'] ?? 'General',
                'tags' => $prompt['tags'] ?? '',
                'is_favorite' => isset($prompt['is_favorite']) ? (bool)$prompt['is_favorite'] : false,
                'uuid' => $prompt['uuid'],
                'created_at' => $prompt['createdAt'] ?? date('c'),
                'updated_at' => $prompt['updatedAt'] ?? date('c'),
                'deleted' => false // Explicitly mark as not deleted
            );
            
            $saved_prompts_meta[] = $prompt_data;
        }
        
        // Update WordPress meta
        update_user_meta($user_id, 'il_user_saved_prompts_structured', $saved_prompts_meta);
    }
    
    /**
     * Mark prompt as deleted (for sync tracking)
     */
    public static function mark_prompt_deleted($user_id, $prompt_uuid) {
        // Log the deletion for sync purposes
        self::log_sync_activity($user_id, 'delete_prompt', array(
            'prompt_uuid' => $prompt_uuid,
            'deleted_at' => current_time('c')
        ), $prompt_uuid);
        
        // Get current prompts
        $saved_prompts_meta = get_user_meta($user_id, 'il_user_saved_prompts_structured', true);
        
        if (empty($saved_prompts_meta) || !is_array($saved_prompts_meta)) {
            return;
        }
        
        // Mark prompt as deleted instead of removing it
        $updated = false;
        foreach ($saved_prompts_meta as $index => $prompt_data) {
            if (isset($prompt_data['uuid']) && $prompt_data['uuid'] === $prompt_uuid) {
                $saved_prompts_meta[$index]['deleted'] = true;
                $saved_prompts_meta[$index]['deleted_at'] = current_time('c');
                $updated = true;
                break;
            }
        }
        
        if ($updated) {
            update_user_meta($user_id, 'il_user_saved_prompts_structured', $saved_prompts_meta);
        }
    }
    
    /**
     * Save local prompt to server
     */
    private static function save_local_prompt_to_server($prompt, $user_id) {
        $saved_prompts_meta = get_user_meta($user_id, 'il_user_saved_prompts_structured', true);
        
        if (empty($saved_prompts_meta) || !is_array($saved_prompts_meta)) {
            $saved_prompts_meta = array();
        }
        
        // Convert to WordPress format
        $prompt_data = array(
            'text' => $prompt['content'],
            'title' => $prompt['title'] ?? 'Untitled Prompt',
            'category' => $prompt['category'] ?? 'General',
            'tags' => $prompt['tags'] ?? '',
            'is_favorite' => isset($prompt['is_favorite']) ? (bool)$prompt['is_favorite'] : false,
            'uuid' => $prompt['uuid'],
            'created_at' => $prompt['createdAt'] ?? date('c'),
            'updated_at' => date('c'),
            'deleted' => false
        );
        
        // Check if prompt already exists
        $existing_index = null;
        foreach ($saved_prompts_meta as $index => $existing_prompt) {
            if (isset($existing_prompt['uuid']) && $existing_prompt['uuid'] === $prompt['uuid']) {
                $existing_index = $index;
                break;
            }
        }
        
        if ($existing_index !== null) {
            // Update existing
            $saved_prompts_meta[$existing_index] = $prompt_data;
        } else {
            // Add new
            $saved_prompts_meta[] = $prompt_data;
        }
        
        // Save to WordPress
        update_user_meta($user_id, 'il_user_saved_prompts_structured', $saved_prompts_meta);
    }
    
    /**
     * Get user plan status
     */
    private static function get_user_plan_status($user_id) {
        $saved_prompts_meta = get_user_meta($user_id, 'il_user_saved_prompts_structured', true);
        
        // Count only non-deleted prompts
        $current_count = 0;
        if (is_array($saved_prompts_meta)) {
            foreach ($saved_prompts_meta as $prompt_data) {
                if (!isset($prompt_data['deleted']) || !$prompt_data['deleted']) {
                    $current_count++;
                }
            }
        }
        
        // Check if user has premium plan
        $is_premium = self::user_has_premium_plan($user_id);
        
        $settings = get_option('il_premium_sync_settings');
        $free_limit = $settings['free_prompt_limit'] ?? 30;
        
        return array(
            'planType' => $is_premium ? 'premium' : 'free',
            'promptLimit' => $is_premium ? -1 : $free_limit,
            'currentCount' => $current_count,
            'isPremium' => $is_premium,
            'canSave' => $is_premium || $current_count < $free_limit
        );
    }
    
    /**
     * Check if user has premium plan
     */
    private static function user_has_premium_plan($user_id) {
        // Check user meta for premium status
        $premium_status = get_user_meta($user_id, 'il_premium_plan', true);
        
        if ($premium_status === 'active') {
            return true;
        }
        
        // Check user roles
        $user = get_user_by('id', $user_id);
        if ($user && in_array('premium_member', $user->roles)) {
            return true;
        }
        
        // Check membership plugin (Ultimate Member, MemberPress, etc.)
        if (function_exists('um_user_can')) {
            if (um_user_can('access_premium_content', $user_id)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Log sync activity
     */
    private static function log_sync_activity($user_id, $action, $data = array(), $prompt_id = null) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'il_sync_log';
        
        $wpdb->insert(
            $table_name,
            array(
                'user_id' => $user_id,
                'action' => $action,
                'prompt_id' => $prompt_id,
                'data' => json_encode($data),
                'timestamp' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s', '%s')
        );
    }
    
    /**
     * Generate UUID
     */
    private static function generate_uuid() {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
}

