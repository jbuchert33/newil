<?php
/**
 * API Prompts Class - FIXED VERSION
 * Handles CRUD operations for prompts with proper deletion tracking
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class IL_API_Prompts {
    
    /**
     * Get user prompts from WordPress meta (excluding deleted ones)
     */
    public static function get_prompts($request) {
        $user_id = IL_API_Auth::validate_token($request);
        
        if (is_wp_error($user_id)) {
            return $user_id;
        }
        
        // Get prompts from user meta
        $saved_prompts_meta = get_user_meta($user_id, 'il_user_saved_prompts_structured', true);
        
        if (empty($saved_prompts_meta) || !is_array($saved_prompts_meta)) {
            $saved_prompts_meta = array();
        }
        
        // Convert to extension format, excluding deleted prompts
        $prompts = array();
        
        foreach ($saved_prompts_meta as $index => $prompt_data) {
            if (isset($prompt_data['text']) && !empty($prompt_data['text'])) {
                // Skip deleted prompts
                if (isset($prompt_data['deleted']) && $prompt_data['deleted']) {
                    continue;
                }
                
                $prompts[] = array(
                    'uuid' => isset($prompt_data['uuid']) ? $prompt_data['uuid'] : self::generate_uuid(),
                    'id' => $index,
                    'title' => isset($prompt_data['title']) ? $prompt_data['title'] : 'Untitled Prompt',
                    'content' => $prompt_data['text'],
                    'category' => isset($prompt_data['category']) ? $prompt_data['category'] : 'General',
                    'tags' => isset($prompt_data['tags']) ? $prompt_data['tags'] : '',
                    'is_favorite' => isset($prompt_data['is_favorite']) ? (bool)$prompt_data['is_favorite'] : false,
                    'favorite' => isset($prompt_data['is_favorite']) ? (bool)$prompt_data['is_favorite'] : false,
                    'source' => 'server',
                    'createdAt' => isset($prompt_data['created_at']) ? $prompt_data['created_at'] : date('c'),
                    'updatedAt' => isset($prompt_data['updated_at']) ? $prompt_data['updated_at'] : date('c')
                );
            }
        }
        
        return rest_ensure_response(array(
            'success' => true,
            'prompts' => $prompts,
            'total' => count($prompts)
        ));
    }
    
    /**
     * Save a prompt to WordPress meta
     */
    public static function save_prompt($request) {
        $user_id = IL_API_Auth::validate_token($request);
        
        if (is_wp_error($user_id)) {
            return $user_id;
        }
        
        $params = $request->get_params();
        
        // Validate required fields
        if (empty($params['title']) || empty($params['content'])) {
            return new WP_Error('missing_fields', 'Title and content are required', array('status' => 400));
        }
        
        // Check plan limits
        $plan_status = self::get_user_plan_status($user_id);
        
        if (!$plan_status['can_save']) {
            return new WP_Error('limit_reached', 'Prompt limit reached. Upgrade to Premium for unlimited prompts.', array('status' => 403));
        }
        
        // Get existing prompts
        $saved_prompts_meta = get_user_meta($user_id, 'il_user_saved_prompts_structured', true);
        
        if (empty($saved_prompts_meta) || !is_array($saved_prompts_meta)) {
            $saved_prompts_meta = array();
        }
        
        // Create prompt data in WordPress format
        $prompt_data = array(
            'text' => sanitize_textarea_field($params['content']),
            'title' => sanitize_text_field($params['title']),
            'category' => sanitize_text_field($params['category'] ?? 'General'),
            'tags' => sanitize_text_field($params['tags'] ?? ''),
            'is_favorite' => isset($params['is_favorite']) ? (bool)$params['is_favorite'] : false,
            'uuid' => isset($params['uuid']) ? sanitize_text_field($params['uuid']) : self::generate_uuid(),
            'created_at' => isset($params['createdAt']) ? $params['createdAt'] : date('c'),
            'updated_at' => date('c'),
            'deleted' => false // Explicitly mark as not deleted
        );
        
        // Check if updating existing prompt
        $existing_index = null;
        if (isset($params['uuid']) || isset($params['id'])) {
            $search_uuid = $params['uuid'] ?? null;
            $search_id = $params['id'] ?? null;
            
            foreach ($saved_prompts_meta as $index => $existing_prompt) {
                if (($search_uuid && isset($existing_prompt['uuid']) && $existing_prompt['uuid'] === $search_uuid) ||
                    ($search_id !== null && $index == $search_id)) {
                    $existing_index = $index;
                    break;
                }
            }
        }
        
        if ($existing_index !== null) {
            // Update existing prompt
            $saved_prompts_meta[$existing_index] = $prompt_data;
        } else {
            // Add new prompt
            $saved_prompts_meta[] = $prompt_data;
        }
        
        // Save to WordPress
        $result = update_user_meta($user_id, 'il_user_saved_prompts_structured', $saved_prompts_meta);
        
        if ($result === false) {
            return new WP_Error('save_failed', 'Failed to save prompt', array('status' => 500));
        }
        
        // Convert back to extension format for response
        $response_prompt = array(
            'uuid' => $prompt_data['uuid'],
            'id' => $existing_index ?? (count($saved_prompts_meta) - 1),
            'title' => $prompt_data['title'],
            'content' => $prompt_data['text'],
            'category' => $prompt_data['category'],
            'tags' => $prompt_data['tags'],
            'is_favorite' => $prompt_data['is_favorite'],
            'favorite' => $prompt_data['is_favorite'],
            'source' => 'server',
            'createdAt' => $prompt_data['created_at'],
            'updatedAt' => $prompt_data['updated_at']
        );
        
        return rest_ensure_response(array(
            'success' => true,
            'prompt' => $response_prompt,
            'message' => 'Prompt saved successfully'
        ));
    }
    
    /**
     * Delete a prompt with proper tracking
     */
    public static function delete_prompt($request) {
        $user_id = IL_API_Auth::validate_token($request);
        
        if (is_wp_error($user_id)) {
            return $user_id;
        }
        
        $prompt_id = $request->get_param('id');
        
		
		if (!$request->has_param('id')) {
            return new WP_Error('missing_id', 'Prompt ID is required', array('status' => 400));
        }
       
        $prompt_id = $request->get_param('id');
        
        // Get existing prompts
        $saved_prompts_meta = get_user_meta($user_id, 'il_user_saved_prompts_structured', true);
        
        if (empty($saved_prompts_meta) || !is_array($saved_prompts_meta)) {
            return new WP_Error('prompt_not_found', 'Prompt not found', array('status' => 404));
        }
        
        // Find and mark prompt as deleted (don't remove it)
        $found = false;
        $prompt_uuid = null;
        
        foreach ($saved_prompts_meta as $index => $prompt_data) {
            $matches = false;
            
            // Check by UUID or index
            if (isset($prompt_data['uuid']) && $prompt_data['uuid'] === $prompt_id) {
                $matches = true;
                $prompt_uuid = $prompt_data['uuid'];
            } elseif ($index == $prompt_id) {
                $matches = true;
                $prompt_uuid = isset($prompt_data['uuid']) ? $prompt_data['uuid'] : $prompt_id;
            }
            
            if ($matches) {
                $found = true;
                // Mark as deleted instead of removing
                $saved_prompts_meta[$index]['deleted'] = true;
                $saved_prompts_meta[$index]['deleted_at'] = current_time('c');
                break;
            }
        }
        
        if (!$found) {
            return new WP_Error('prompt_not_found', 'Prompt not found', array('status' => 404));
        }
        
        // Update user meta
        $result = update_user_meta($user_id, 'il_user_saved_prompts_structured', $saved_prompts_meta);
        
        if ($result === false) {
            return new WP_Error('delete_failed', 'Failed to delete prompt', array('status' => 500));
        }
        
        // Log deletion for sync tracking
        IL_API_Sync::mark_prompt_deleted($user_id, $prompt_uuid);
        
        return rest_ensure_response(array(
            'success' => true,
            'message' => 'Prompt deleted successfully',
            'deleted_uuid' => $prompt_uuid
        ));
    }
    
    /**
     * Get user plan status
     */
    public static function get_plan_status($request) {
        $user_id = IL_API_Auth::validate_token($request);
        
        if (is_wp_error($user_id)) {
            return $user_id;
        }
        
        $plan_status = self::get_user_plan_status($user_id);
        
        return rest_ensure_response($plan_status);
    }
    
    /**
     * Get user plan status (internal method)
     */
    private static function get_user_plan_status($user_id) {
        // Get current prompt count (excluding deleted ones)
        $saved_prompts_meta = get_user_meta($user_id, 'il_user_saved_prompts_structured', true);
        $current_count = 0;
        
        if (is_array($saved_prompts_meta)) {
            foreach ($saved_prompts_meta as $prompt_data) {
                if (!isset($prompt_data['deleted']) || !$prompt_data['deleted']) {
                    $current_count++;
                }
            }
        }
        
        // Check if user has premium plan
        $is_premium = self::user_has_premium_plan($user_id);
        
        $settings = get_option('il_premium_sync_settings');
        $free_limit = $settings['free_prompt_limit'] ?? 30;
        
        if ($is_premium) {
            return array(
                'success' => true,
                'planType' => 'premium',
                'promptLimit' => -1, // Unlimited
                'currentCount' => $current_count,
                'isPremium' => true,
                'canSave' => true,
                'can_save' => true // Alias for compatibility
            );
        } else {
            return array(
                'success' => true,
                'planType' => 'free',
                'promptLimit' => $free_limit,
                'currentCount' => $current_count,
                'isPremium' => false,
                'canSave' => $current_count < $free_limit,
                'can_save' => $current_count < $free_limit // Alias for compatibility
            );
        }
    }
    
    /**
     * Check if user has premium plan
     */
    private static function user_has_premium_plan($user_id) {
        // Check user meta for premium status
        $premium_status = get_user_meta($user_id, 'il_premium_plan', true);
        
        if ($premium_status === 'active') {
            return true;
        }
        
        // Check user roles
        $user = get_user_by('id', $user_id);
        if ($user && in_array('premium_member', $user->roles)) {
            return true;
        }
        
        // Check membership plugin (Ultimate Member, MemberPress, etc.)
        if (function_exists('um_user_can')) {
            if (um_user_can('access_premium_content', $user_id)) {
                return true;
            }
        }
        
        // Default to free plan
        return false;
    }
    
    /**
     * Generate UUID
     */
    private static function generate_uuid() {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
}

