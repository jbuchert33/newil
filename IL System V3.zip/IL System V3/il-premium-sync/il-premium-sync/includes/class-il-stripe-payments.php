<?php
/**
 * Stripe Payments Class
 * Handles Stripe integration for premium plan payments
 * IMPROVED: Added better error handling, logging, and post-payment sync
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class IL_Stripe_Payments {
    
    private $stripe_secret_key;
    private $stripe_publishable_key;
    private $webhook_secret;
    private $success_url;
    private $cancel_url;
    
    /**
     * Constructor
     */
    public function __construct() {
        error_log('[IL LOG] IL_Stripe_Payments constructor called.'); // LOGGING
        // Get Stripe API keys from settings
        $settings = get_option('il_premium_sync_settings');
        $this->stripe_secret_key = $settings['stripe_secret_key'] ?? '';
        $this->stripe_publishable_key = $settings['stripe_publishable_key'] ?? '';
        $this->webhook_secret = $settings['stripe_webhook_secret'] ?? '';
        
        // Set default URLs
        $this->success_url = home_url('/premium-success');
        $this->cancel_url = home_url('/premium-cancel');
        
        // Initialize hooks
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_il_create_checkout_session', array($this, 'ajax_create_checkout_session'));
        add_action('wp_ajax_nopriv_il_create_checkout_session', array($this, 'ajax_create_checkout_session'));
        
        // Add shortcodes
        add_shortcode('il_premium_checkout', array($this, 'checkout_shortcode'));
        add_shortcode('il_premium_status', array($this, 'status_shortcode'));
    }
    
    /**
     * Register REST API routes
     */
    public function register_rest_routes() {
        error_log('[IL LOG] IL_Stripe_Payments::register_rest_routes called.'); // LOGGING
        register_rest_route('il-sync/v1', '/stripe/webhook', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_webhook'),
            'permission_callback' => '__return_true'
        ));
        
        register_rest_route('il-sync/v1', '/stripe/create-checkout', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_checkout_session'),
            'permission_callback' => array('IL_API_Auth', 'check_permission')
        ));
        
        register_rest_route('il-sync/v1', '/stripe/create-checkout-direct', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_checkout_session_direct'),
            'permission_callback' => '__return_true'
        ));
        
        register_rest_route('il-sync/v1', '/stripe/customer-portal', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_customer_portal'),
            'permission_callback' => array('IL_API_Auth', 'check_permission')
        ));
    }
    
    /**
     * Enqueue scripts for Stripe integration
     */
    public function enqueue_scripts() {
        // Only enqueue on pages with our shortcode
        global $post;
        if (is_a($post, 'WP_Post') && (has_shortcode($post->post_content, 'il_premium_checkout') || has_shortcode($post->post_content, 'il_premium_status'))) {
            wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/', array(), null, true);
            wp_enqueue_script('il-stripe', plugin_dir_url(dirname(__FILE__)) . 'assets/js/stripe.js', array('jquery', 'stripe-js'), '1.0.0', true);
            
            wp_localize_script('il-stripe', 'il_stripe_params', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'publishable_key' => $this->stripe_publishable_key,
                'nonce' => wp_create_nonce('il-stripe-nonce')
            ));
        }
    }
    
    /**
     * Create checkout session via AJAX
     */
    public function ajax_create_checkout_session() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'il-stripe-nonce')) {
            wp_send_json_error(array('message' => 'Invalid nonce'));
            exit;
        }
        
        $plan_id = isset($_POST['plan_id']) ? sanitize_text_field($_POST['plan_id']) : 'monthly';
        $user_id = get_current_user_id();
        
        if (!$user_id) {
            wp_send_json_error(array('message' => 'User not logged in'));
            exit;
        }
        
        try {
            $session = $this->create_stripe_checkout_session($user_id, $plan_id);
            wp_send_json_success(array('session_id' => $session->id));
        } catch (Exception $e) {
            wp_send_json_error(array('message' => $e->getMessage()));
        }
        
        exit;
    }
    
    /**
     * Create checkout session via REST API
     */
    public function create_checkout_session($request) {
        $user_id = IL_API_Auth::validate_token($request);
        
        if (is_wp_error($user_id)) {
            return $user_id;
        }
        
        $params = $request->get_params();
        $plan_id = isset($params['plan_id']) ? sanitize_text_field($params['plan_id']) : 'monthly';
        
        try {
            $session = $this->create_stripe_checkout_session($user_id, $plan_id);
            
            return rest_ensure_response(array(
                'success' => true,
                'session_id' => $session->id,
                'checkout_url' => $session->url
            ));
        } catch (Exception $e) {
            return new WP_Error('stripe_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Create checkout session without authentication - DIRECT STRIPE REDIRECT
     */
    public function create_checkout_session_direct($request) {
        $params = $request->get_params();
        $plan_id = isset($params['plan_id']) ? sanitize_text_field($params['plan_id']) : 'monthly';
        
        try {
            // Create session without user authentication
            $session = $this->create_stripe_checkout_session_guest($plan_id);
            
            return rest_ensure_response(array(
                'success' => true,
                'session_id' => $session->id,
                'checkout_url' => $session->url
            ));
        } catch (Exception $e) {
            return new WP_Error('stripe_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Create customer portal session via REST API
     */
    public function create_customer_portal($request) {
        error_log('[IL LOG] create_customer_portal endpoint hit.'); // LOGGING

        error_log('[IL LOG] Step 1: Validating auth token.'); // LOGGING
        $user_id = IL_API_Auth::validate_token($request);
        
        if (is_wp_error($user_id)) {
            error_log('[IL LOG] Auth token validation failed: ' . $user_id->get_error_message()); // LOGGING
            return $user_id;
        }
        error_log('[IL LOG] Auth token validated. User ID: ' . $user_id); // LOGGING

        error_log('[IL LOG] Step 2: Checking for Stripe SDK.'); // LOGGING
        if (!class_exists('\Stripe\Stripe')) {
            $stripe_init_file = plugin_dir_path(dirname(__FILE__)) . 'vendor/stripe/init.php';
            if (file_exists($stripe_init_file)) {
                require_once $stripe_init_file;
                error_log('[IL LOG] Stripe SDK loaded from init file.'); // LOGGING
            } else {
                error_log('[IL LOG] FATAL: Stripe SDK not found.'); // LOGGING
                return new WP_Error('stripe_sdk_missing', 'The Stripe PHP library is missing from the plugin.', array('status' => 500));
            }
        }
        
        error_log('[IL LOG] Step 3: Getting Stripe customer ID from user meta.'); // LOGGING
        $stripe_customer_id = get_user_meta($user_id, 'il_stripe_customer_id', true);
        
        if (!$stripe_customer_id) {
            error_log('[IL LOG] Stripe customer ID not found for user ' . $user_id); // LOGGING
            return new WP_Error('customer_not_found', 'No Stripe customer found for this user', array('status' => 404));
        }
        error_log('[IL LOG] Found Stripe customer ID: ' . $stripe_customer_id); // LOGGING
        
        try {
            error_log('[IL LOG] Step 4: Setting Stripe API key.'); // LOGGING
            if(empty($this->stripe_secret_key)) {
                error_log('[IL LOG] FATAL: Stripe Secret Key is empty!'); // LOGGING
                throw new Exception('Stripe Secret Key is not configured on the server.');
            }
            \Stripe\Stripe::setApiKey($this->stripe_secret_key);
            
            error_log('[IL LOG] Step 5: Creating Stripe Billing Portal session.'); // LOGGING
            $session = \Stripe\BillingPortal\Session::create([
                'customer' => $stripe_customer_id,
                'return_url' => home_url('/account'),
            ]);
            
            error_log('[IL LOG] Successfully created portal session. URL: ' . $session->url); // LOGGING
            return rest_ensure_response(array(
                'success' => true,
                'portal_url' => $session->url
            ));
        } catch (Exception $e) {
            error_log('[IL LOG] EXCEPTION in create_customer_portal: ' . $e->getMessage()); // LOGGING
            return new WP_Error('stripe_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Handle Stripe webhook
     * IMPROVED: Added better error handling and logging
     */
    public function handle_webhook($request) {
        $payload = $request->get_body();
        $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';
        
        error_log('IL Premium: Stripe webhook received');
        
        try {
            \Stripe\Stripe::setApiKey($this->stripe_secret_key);
            $event = \Stripe\Webhook::constructEvent($payload, $sig_header, $this->webhook_secret);
            
            error_log('IL Premium: Webhook event type: ' . $event->type);
            
            // Handle the event
            switch ($event->type) {
                case 'checkout.session.completed':
                    $session = $event->data->object;
                    error_log('IL Premium: Processing checkout.session.completed for session ID: ' . $session->id);
                    $this->handle_checkout_session_completed($session);
                    break;
                    
                case 'customer.subscription.created':
                case 'customer.subscription.updated':
                    $subscription = $event->data->object;
                    error_log('IL Premium: Processing subscription update for subscription ID: ' . $subscription->id);
                    $this->handle_subscription_updated($subscription);
                    break;
                    
                case 'customer.subscription.deleted':
                    $subscription = $event->data->object;
                    error_log('IL Premium: Processing subscription deletion for subscription ID: ' . $subscription->id);
                    $this->handle_subscription_deleted($subscription);
                    break;
                    
                case 'invoice.payment_succeeded':
                    $invoice = $event->data->object;
                    error_log('IL Premium: Processing invoice payment success for invoice ID: ' . $invoice->id);
                    $this->handle_invoice_payment_succeeded($invoice);
                    break;
                    
                case 'invoice.payment_failed':
                    $invoice = $event->data->object;
                    error_log('IL Premium: Processing invoice payment failure for invoice ID: ' . $invoice->id);
                    $this->handle_invoice_payment_failed($invoice);
                    break;
                    
                default:
                    error_log('IL Premium: Unhandled webhook event type: ' . $event->type);
            }
            
            return rest_ensure_response(array('success' => true));
            
        } catch (\Stripe\Exception\SignatureVerificationException $e) {
            error_log('IL Premium: Webhook signature verification failed: ' . $e->getMessage());
            return new WP_Error('webhook_signature_error', $e->getMessage(), array('status' => 400));
        } catch (Exception $e) {
            error_log('IL Premium: Webhook error: ' . $e->getMessage());
            return new WP_Error('webhook_error', $e->getMessage(), array('status' => 400));
        }
    }
    
    /**
     * Create Stripe checkout session for authenticated user
     */
    private function create_stripe_checkout_session($user_id, $plan_id = 'monthly') {
        // Validate Stripe configuration
        if (empty($this->stripe_secret_key)) {
            throw new Exception('Stripe secret key is not configured. Please configure your Stripe keys in WordPress Admin → Settings → IL Premium Sync.');
        }
        
        // Load Stripe PHP library
        if (!class_exists('\Stripe\Stripe')) {
            $stripe_init_file = plugin_dir_path(dirname(__FILE__)) . 'vendor/stripe/init.php';
            if (file_exists($stripe_init_file)) {
                require_once $stripe_init_file;
            } else {
                throw new Exception('Stripe PHP library is not available. Please install the Stripe PHP SDK or use a plugin that provides it.');
            }
        }
        
        \Stripe\Stripe::setApiKey($this->stripe_secret_key);
        
        $user = get_user_by('id', $user_id);
        if (!$user) {
            throw new Exception('User not found');
        }
        
        // Get price ID based on plan
        $price_id = $this->get_price_id_for_plan($plan_id);
        
        if (empty($price_id) || strpos($price_id, 'price_') !== 0) {
            throw new Exception('Invalid Stripe price ID for plan: ' . $plan_id . '. Please configure your Stripe price IDs in WordPress Admin → Settings → IL Premium Sync.');
        }
        
        // Get or create Stripe customer
        $stripe_customer_id = get_user_meta($user_id, 'il_stripe_customer_id', true);
        
        try {
            if (!$stripe_customer_id) {
                $customer = \Stripe\Customer::create([
                    'email' => $user->user_email,
                    'name' => $user->display_name,
                    'metadata' => [
                        'user_id' => $user_id,
                        'site_url' => home_url()
                    ]
                ]);
                
                $stripe_customer_id = $customer->id;
                update_user_meta($user_id, 'il_stripe_customer_id', $stripe_customer_id);
            }
            
            // Create checkout session
            $session = \Stripe\Checkout\Session::create([
                'customer' => $stripe_customer_id,
                'payment_method_types' => ['card'],
                'line_items' => [[
                    'price' => $price_id,
                    'quantity' => 1,
                ]],
                'mode' => 'subscription',
				'automatic_tax'              => ['enabled' => true],
				'billing_address_collection' => 'auto',
                'success_url' => $this->success_url . '?session_id={CHECKOUT_SESSION_ID}&email=' . urlencode($user->user_email),
                'cancel_url' => $this->cancel_url,
                'metadata' => [
                    'user_id' => $user_id,
                    'plan_id' => $plan_id,
                    'user_email' => $user->user_email
                ]
            ]);
            
            return $session;
        } catch (\Stripe\Exception\ApiErrorException $e) {
            throw new Exception('Stripe API Error: ' . $e->getMessage());
        } catch (Exception $e) {
            throw new Exception('Error creating checkout session: ' . $e->getMessage());
        }
    }
    
    /**
     * Create Stripe checkout session for guest users - DIRECT STRIPE REDIRECT
     */
    private function create_stripe_checkout_session_guest($plan_id = 'monthly') {
        // Validate Stripe configuration
        if (empty($this->stripe_secret_key)) {
            throw new Exception('Stripe secret key is not configured. Please configure your Stripe keys in WordPress Admin → Settings → IL Premium Sync.');
        }
        
        // Load Stripe PHP library
        if (!class_exists('\Stripe\Stripe')) {
            $stripe_init_file = plugin_dir_path(dirname(__FILE__)) . 'vendor/stripe/init.php';
            if (file_exists($stripe_init_file)) {
                require_once $stripe_init_file;
            } else {
                throw new Exception('Stripe PHP library is not available. Please install the Stripe PHP SDK or use a plugin that provides it.');
            }
        }
        
        \Stripe\Stripe::setApiKey($this->stripe_secret_key);
        
        // Get price ID based on plan
        $price_id = $this->get_price_id_for_plan($plan_id);
        
        if (empty($price_id) || strpos($price_id, 'price_') !== 0) {
            throw new Exception('Invalid Stripe price ID for plan: ' . $plan_id . '. Please configure your Stripe price IDs in WordPress Admin → Settings → IL Premium Sync.');
        }
        
        try {
            // Create checkout session without pre-existing customer
            // User will identify themselves with email on Stripe
            $session = \Stripe\Checkout\Session::create([
                'payment_method_types' => ['card'],
                'line_items' => [[
                    'price' => $price_id,
                    'quantity' => 1,
                ]],
                'mode' => 'subscription',
                'success_url' => $this->success_url . '?session_id={CHECKOUT_SESSION_ID}&email={CHECKOUT_SESSION_CUSTOMER_EMAIL}',
                'cancel_url' => $this->cancel_url,
                'customer_email' => null, // Let user enter their email
                'allow_promotion_codes' => true,
				'automatic_tax'              => ['enabled' => true],
                'billing_address_collection' => 'auto',
                'metadata' => [
                    'plan_id' => $plan_id,
                    'source' => 'direct_checkout',
                    'site_url' => home_url()
                ]
            ]);
            
            return $session;
        } catch (\Stripe\Exception\ApiErrorException $e) {
            throw new Exception('Stripe API Error: ' . $e->getMessage());
        } catch (Exception $e) {
            throw new Exception('Error creating checkout session: ' . $e->getMessage());
        }
    }
    
    /**
     * Get Stripe price ID for plan
     */
    private function get_price_id_for_plan($plan_id) {
        $settings = get_option('il_premium_sync_settings');
        
        // Check for specific price ID configuration
        if (isset($settings['stripe_monthly_price_id']) && $plan_id === 'monthly') {
            return $settings['stripe_monthly_price_id'];
        }
        
        if (isset($settings['stripe_yearly_price_id']) && $plan_id === 'yearly') {
            return $settings['stripe_yearly_price_id'];
        }
        
        // Legacy format support
        $price_ids = $settings['stripe_price_ids'] ?? array();
        if (isset($price_ids[$plan_id])) {
            return $price_ids[$plan_id];
        }
        
        // No valid price ID found - return empty to trigger error
        return '';
    }
    
    /**
     * Handle checkout session completed
     * IMPROVED: Added better error handling, logging, and user identification
     */
    private function handle_checkout_session_completed($session) {
        // Debugging logs
        error_log('IL Premium: Webhook checkout.session.completed received for session: ' . $session->id);
        error_log('IL Premium: Session metadata user_id: ' . ($session->metadata->user_id ?? 'N/A'));
        error_log('IL Premium: Session customer email: ' . ($session->customer_details->email ?? 'N/A'));
        error_log('IL Premium: Session customer ID: ' . ($session->customer ?? 'N/A'));
        
        $user_id = $session->metadata->user_id ?? null;
        
        // If no user_id in metadata, try to find user by customer email
        if (!$user_id && isset($session->customer_details->email)) {
            $user = get_user_by('email', $session->customer_details->email);
            if ($user) {
                $user_id = $user->ID;
                error_log('IL Premium: Found user by email: ' . $session->customer_details->email . ', user ID: ' . $user_id);
            }
        }
        
        // If still no user, try to find by customer ID
        if (!$user_id && isset($session->customer)) {
            $user_id = $this->get_user_id_by_customer_id($session->customer);
            if ($user_id) {
                error_log('IL Premium: Found user by customer ID: ' . $session->customer . ', user ID: ' . $user_id);
            }
        }
        
        // If still no user, create one with the email from Stripe
        if (!$user_id && isset($session->customer_details->email)) {
            $email = $session->customer_details->email;
            $name = $session->customer_details->name ?? '';
            
            error_log('IL Premium: No existing user found, checking if email exists: ' . $email);
            
            // Check if user already exists
            $existing_user = get_user_by('email', $email);
            if (!$existing_user) {
                error_log('IL Premium: Creating new user with email: ' . $email);
                
                // Create new user
                $username = sanitize_user(str_replace('@', '_', $email));
                $password = wp_generate_password();
                
                $user_id = wp_create_user($username, $password, $email);
                
                if (!is_wp_error($user_id)) {
                    error_log('IL Premium: New user created with ID: ' . $user_id);
                    
                    // Update display name if provided
                    if ($name) {
                        wp_update_user(array(
                            'ID' => $user_id,
                            'display_name' => $name
                        ));
                    }
                    
                    // Send welcome email with login details
                    $this->send_welcome_email($user_id, $username, $password);
                } else {
                    error_log('IL Premium: Error creating user: ' . $user_id->get_error_message());
                }
            } else {
                $user_id = $existing_user->ID;
                error_log('IL Premium: Found existing user by email: ' . $email . ', user ID: ' . $user_id);
            }
        }
        
        error_log('IL Premium: Determined user_id: ' . ($user_id ?? 'N/A'));
        
        if (!$user_id) {
            error_log('IL Premium: Could not determine user for checkout session: ' . $session->id);
            return;
        }
        
        // Store subscription ID
        if (isset($session->subscription)) {
            update_user_meta($user_id, 'il_stripe_subscription_id', $session->subscription);
            error_log('IL Premium: Stored subscription ID: ' . $session->subscription . ' for user: ' . $user_id);
        }
        
        // Store customer ID
        if (isset($session->customer)) {
            update_user_meta($user_id, 'il_stripe_customer_id', $session->customer);
            error_log('IL Premium: Stored customer ID: ' . $session->customer . ' for user: ' . $user_id);
        }
        
        // Activate premium plan
        IL_API_Payments::update_payment_status($user_id, 'active', $session->subscription ?? null);
        
        // Log the event
        $this->log_payment_event($user_id, 'subscription_created', array(
            'session_id' => $session->id,
            'subscription_id' => $session->subscription ?? null,
            'customer_id' => $session->customer ?? null,
            'plan_id' => $session->metadata->plan_id ?? 'monthly',
            'email' => $session->customer_details->email ?? null
        ));
        
        error_log('IL Premium: Successfully activated premium for user ' . $user_id . ' from session ' . $session->id);
    }
    
    /**
     * Send welcome email to new premium user
     */
    private function send_welcome_email($user_id, $username, $password) {
        $user = get_user_by('id', $user_id);
        if (!$user) {
            return;
        }
        
        $site_name = get_bloginfo('name');
        $login_url = wp_login_url();
        $extension_url = 'https://chrome.google.com/webstore'; // Update with actual extension URL
        
        $subject = sprintf('[%s] Bienvenue dans IL Premium !', $site_name);
        
        $message = sprintf(
            "Bonjour %s,\n\n" .
            "Félicitations ! Votre abonnement IL Premium est maintenant actif.\n\n" .
            "Vos informations de connexion :\n" .
            "Nom d'utilisateur : %s\n" .
            "Mot de passe : %s\n" .
            "URL de connexion : %s\n\n" .
            "Pour utiliser vos fonctionnalités premium :\n" .
            "1. Installez l'extension IL Premium : %s\n" .
            "2. Connectez-vous avec vos identifiants ci-dessus\n" .
            "3. Profitez de vos prompts illimités !\n\n" .
            "Si vous avez des questions, n'hésitez pas à nous contacter.\n\n" .
            "Merci de votre confiance !\n" .
            "L'équipe %s",
            $user->display_name ?: $user->user_login,
            $username,
            $password,
            $login_url,
            $extension_url,
            $site_name
        );
        
        wp_mail($user->user_email, $subject, $message);
        error_log('IL Premium: Welcome email sent to: ' . $user->user_email);
    }
    
    // In class-il-stripe-payments.php, REPLACE the entire function

	/**
	 * Handle subscription updated
	 * IMPROVED: Added logic to find user by email from the customer object if not found by ID.
	 */
	private function handle_subscription_updated($subscription) {
		$customer_id = $subscription->customer;
		$user_id = $this->get_user_id_by_customer_id($customer_id);

		// If user_id is not found by the customer ID, try to find them by email.
		if (!$user_id) {
			error_log('[IL Premium] handle_subscription_updated: User not found by customer ID ' . $customer_id . '. Attempting to find by email.');
			try {
				// Retrieve the customer object from Stripe to get their email
				$customer = \Stripe\Customer::retrieve($customer_id);
				if (isset($customer->email)) {
					$user = get_user_by('email', $customer->email);
					if ($user) {
						$user_id = $user->ID;
						// This is important: save the customer ID to the user for future webhooks
						update_user_meta($user_id, 'il_stripe_customer_id', $customer_id);
						error_log('[IL Premium] Found user by email (' . $customer->email . ') and linked to customer ID. User ID: ' . $user_id);
					}
				}
			} catch (Exception $e) {
				error_log('[IL Premium] Stripe API error when trying to retrieve customer ' . $customer_id . ': ' . $e->getMessage());
			}
		}

		if (!$user_id) {
			error_log('[IL Premium] Could not find user for subscription: ' . $subscription->id . ' with customer: ' . $customer_id);
			return;
		}

		$status = $subscription->status;
		error_log('IL Premium: Updating subscription status to: ' . $status . ' for user: ' . $user_id);

		if ($status === 'active' || $status === 'trialing') {
			IL_API_Payments::update_payment_status($user_id, $status, $subscription->id);
		} else {
			IL_API_Payments::update_payment_status($user_id, $status, $subscription->id);
		}

		$this->log_payment_event($user_id, 'subscription_updated', array(
			'subscription_id' => $subscription->id,
			'status' => $status,
			'current_period_end' => date('Y-m-d H:i:s', $subscription->current_period_end)
		));

		error_log('IL Premium: Successfully updated subscription status for user ' . $user_id);
	}
    /**
     * Handle subscription deleted
     * IMPROVED: Added better error handling and logging
     */
    private function handle_subscription_deleted($subscription) {
        // Find user by customer ID
        $customer_id = $subscription->customer;
        $user_id = $this->get_user_id_by_customer_id($customer_id);
        
        if (!$user_id) {
            error_log('IL Premium: Could not find user for deleted subscription: ' . $subscription->id . ' with customer: ' . $customer_id);
            return;
        }
        
        error_log('IL Premium: Handling subscription deletion for user: ' . $user_id);
        
        // Deactivate premium plan
        IL_API_Payments::update_payment_status($user_id, 'canceled', $subscription->id);
        
        // Log the event
        $this->log_payment_event($user_id, 'subscription_deleted', array(
            'subscription_id' => $subscription->id,
            'canceled_at' => date('Y-m-d H:i:s', $subscription->canceled_at ?? time())
        ));
        
        error_log('IL Premium: Successfully marked subscription as canceled for user ' . $user_id);
    }
    
    /**
     * Handle invoice payment succeeded
     * IMPROVED: Added better error handling and logging
     */
    private function handle_invoice_payment_succeeded($invoice) {
        // Find user by customer ID
        $customer_id = $invoice->customer;
        $user_id = $this->get_user_id_by_customer_id($customer_id);
        
        if (!$user_id) {
            error_log('IL Premium: Could not find user for invoice: ' . $invoice->id . ' with customer: ' . $customer_id);
            return;
        }
        
        error_log('IL Premium: Handling successful payment for user: ' . $user_id);
        
        // Update payment status
        IL_API_Payments::update_payment_status($user_id, 'active', $invoice->subscription ?? null);
        
        // Log the event
        $this->log_payment_event($user_id, 'payment_succeeded', array(
            'invoice_id' => $invoice->id,
            'amount_paid' => $invoice->amount_paid / 100, // Convert from cents
            'currency' => $invoice->currency,
            'subscription_id' => $invoice->subscription ?? null
        ));
        
        error_log('IL Premium: Successfully updated payment status for user ' . $user_id);
    }
    
    /**
     * Handle invoice payment failed
     * IMPROVED: Added better error handling and logging
     */
    private function handle_invoice_payment_failed($invoice) {
        // Find user by customer ID
        $customer_id = $invoice->customer;
        $user_id = $this->get_user_id_by_customer_id($customer_id);
        
        if (!$user_id) {
            error_log('IL Premium: Could not find user for failed invoice: ' . $invoice->id . ' with customer: ' . $customer_id);
            return;
        }
        
        error_log('IL Premium: Handling failed payment for user: ' . $user_id);
        
        // Update payment status
        IL_API_Payments::update_payment_status($user_id, 'past_due', $invoice->subscription ?? null);
        
        // Log the event
        $this->log_payment_event($user_id, 'payment_failed', array(
            'invoice_id' => $invoice->id,
            'amount_due' => $invoice->amount_due / 100, // Convert from cents
            'currency' => $invoice->currency,
            'subscription_id' => $invoice->subscription ?? null,
            'attempt_count' => $invoice->attempt_count
        ));
        
        // Send email notification
        $this->send_payment_failed_notification($user_id, $invoice);
        
        error_log('IL Premium: Updated payment status to past_due for user ' . $user_id);
    }
    
    /**
     * Get user ID by Stripe customer ID
     * IMPROVED: Added better error handling
     */
    private function get_user_id_by_customer_id($customer_id) {
        global $wpdb;
        
        $user_id = $wpdb->get_var($wpdb->prepare(
            "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = 'il_stripe_customer_id' AND meta_value = %s LIMIT 1",
            $customer_id
        ));
        
        if (!$user_id) {
            error_log('IL Premium: No user found with customer ID: ' . $customer_id);
        }
        
        return $user_id;
    }
    
    /**
     * Log payment event
     * IMPROVED: Added better error handling
     */
    private function log_payment_event($user_id, $event_type, $data = array()) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'il_payment_log';
        
        try {
            $wpdb->insert(
                $table_name,
                array(
                    'user_id' => $user_id,
                    'event_type' => $event_type,
                    'data' => json_encode($data),
                    'timestamp' => current_time('mysql')
                ),
                array('%d', '%s', '%s', '%s')
            );
            
            if ($wpdb->last_error) {
                error_log('IL Premium: Error logging payment event: ' . $wpdb->last_error);
            }
        } catch (Exception $e) {
            error_log('IL Premium: Exception logging payment event: ' . $e->getMessage());
        }
    }
    
    /**
     * Send payment failed notification
     */
    private function send_payment_failed_notification($user_id, $invoice) {
        $user = get_user_by('id', $user_id);
        if (!$user) {
            return;
        }
        
        $subject = 'Payment Failed for Your Premium Subscription';
        
        $message = "Hello {$user->display_name},\n\n";
        $message .= "We were unable to process your payment for your Premium subscription.\n\n";
        $message .= "Amount due: " . ($invoice->amount_due / 100) . " " . strtoupper($invoice->currency) . "\n";
        $message .= "Please update your payment method to continue enjoying Premium features.\n\n";
        $message .= "You can update your payment details here: " . home_url('/account') . "\n\n";
        $message .= "If you have any questions, please contact our support team.\n\n";
        $message .= "Thank you,\n";
        $message .= get_bloginfo('name');
        
        wp_mail($user->user_email, $subject, $message);
        error_log('IL Premium: Payment failed notification sent to: ' . $user->user_email);
    }
    
    /**
     * Checkout shortcode
     */
    public function checkout_shortcode($atts) {
        $atts = shortcode_atts(array(
            'plan' => 'monthly',
            'button_text' => 'Subscribe Now',
            'button_class' => 'button button-primary',
        ), $atts);
        
        if (!is_user_logged_in()) {
            return '<p>Please <a href="' . wp_login_url(get_permalink()) . '">log in</a> to subscribe.</p>';
        }
        
        $user_id = get_current_user_id();
        $premium_status = get_user_meta($user_id, 'il_premium_plan', true);
        
        if ($premium_status === 'active') {
            return '<p>You already have an active Premium subscription. <a href="#" class="il-customer-portal">Manage your subscription</a>.</p>';
        }
        
        $output = '<div class="il-checkout-container">';
        $output .= '<button id="il-checkout-button" class="' . esc_attr($atts['button_class']) . '" data-plan="' . esc_attr($atts['plan']) . '">' . esc_html($atts['button_text']) . '</button>';
        $output .= '<div id="il-checkout-message"></div>';
        $output .= '</div>';
        
        return $output;
    }
    
    /**
     * Status shortcode
     */
    public function status_shortcode($atts) {
        $atts = shortcode_atts(array(
            'manage_text' => 'Manage Subscription',
            'button_class' => 'button button-secondary',
        ), $atts);
        
        if (!is_user_logged_in()) {
            return '<p>Please <a href="' . wp_login_url(get_permalink()) . '">log in</a> to view your subscription status.</p>';
        }
        
        $user_id = get_current_user_id();
        $premium_status = get_user_meta($user_id, 'il_premium_plan', true);
        $status_text = get_user_meta($user_id, 'il_premium_plan_status', true);
        
        $output = '<div class="il-subscription-status">';
        
        if ($premium_status === 'active') {
            $output .= '<p><strong>Status:</strong> Active Premium Subscription</p>';
            
            $last_payment = get_user_meta($user_id, 'il_premium_plan_last_payment', true);
            if ($last_payment) {
                $output .= '<p><strong>Last Payment:</strong> ' . date_i18n(get_option('date_format'), strtotime($last_payment)) . '</p>';
            }
            
            $output .= '<p><a href="#" class="il-customer-portal ' . esc_attr($atts['button_class']) . '">' . esc_html($atts['manage_text']) . '</a></p>';
        } else {
            $output .= '<p><strong>Status:</strong> No active Premium subscription</p>';
            
            if ($status_text === 'past_due') {
                $output .= '<p class="il-payment-issue">There is an issue with your payment method. <a href="#" class="il-customer-portal">Update payment details</a>.</p>';
            } elseif ($status_text === 'canceled') {
                $canceled_date = get_user_meta($user_id, 'il_premium_plan_canceled', true);
                if ($canceled_date) {
                    $output .= '<p>Your subscription was canceled on ' . date_i18n(get_option('date_format'), strtotime($canceled_date)) . '.</p>';
                }
            }
            
            $output .= '<p><a href="' . home_url('/pricing') . '">View Premium Plans</a></p>';
        }
        
        $output .= '</div>';
        
        return $output;
    }
    
    /**
     * Create payment log table
     */
    public static function create_payment_log_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'il_payment_log';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            event_type varchar(50) NOT NULL,
            data longtext,
            timestamp datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY event_type (event_type),
            KEY timestamp (timestamp)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}