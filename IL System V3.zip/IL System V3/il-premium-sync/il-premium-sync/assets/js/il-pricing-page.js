/**
 * IL Premium Pricing Page JavaScript
 * Handles checkout button clicks and Stripe integration
 */

(function() {
    'use strict';
    
    // Configuration
    const CONFIG = {
        API_BASE_URL: 'https://intellectualead.com/wp-json/il-sync/v1',
        STRIPE_PUBLISHABLE_KEY: '', // Will be set from WordPress localized script
        PLANS: {
            monthly: {
                name: 'Premium Monthly',
                price: '$9/month',
                priceId: 'price_monthly' // This should match the Stripe price ID
            },
            yearly: {
                name: 'Premium Yearly', 
                price: '$90/year',
                priceId: 'price_yearly' // This should match the Stripe price ID
            }
        }
    };
    
    // Stripe instance
    let stripe = null;
    
    // Initialize when DOM is ready
    document.addEventListener('DOMContentLoaded', function() {
        console.log('IL Pricing Page: Initializing...');
        initializeStripe();
        setupCheckoutButtons();
        checkUserStatus();
    });
    
    /**
     * Initialize Stripe
     */
    function initializeStripe() {
        // Get Stripe publishable key from WordPress localized script
        if (typeof il_stripe_params !== 'undefined' && il_stripe_params.publishable_key) {
            CONFIG.STRIPE_PUBLISHABLE_KEY = il_stripe_params.publishable_key;
            
            if (window.Stripe) {
                stripe = Stripe(CONFIG.STRIPE_PUBLISHABLE_KEY);
                console.log('IL Pricing Page: Stripe initialized');
            } else {
                console.error('IL Pricing Page: Stripe.js not loaded');
                showMessage('Erreur: Stripe non disponible', 'error');
            }
        } else {
            console.warn('IL Pricing Page: Stripe keys not found, using test mode');
            // For testing purposes, we'll still set up the buttons
        }
    }
    
    /**
     * Setup checkout button event listeners
     */
    function setupCheckoutButtons() {
        const checkoutButtons = document.querySelectorAll('.il-checkout-button');
        
        console.log(`IL Pricing Page: Found ${checkoutButtons.length} checkout buttons`);
        
        checkoutButtons.forEach(button => {
            button.addEventListener('click', handleCheckoutClick);
            
            // Add loading state capability
            button.dataset.originalText = button.textContent;
        });
    }
    
    /**
     * Handle checkout button click - MODIFIED for direct Stripe redirect
     */
    async function handleCheckoutClick(event) {
        event.preventDefault();
        
        const button = event.currentTarget;
        const planId = button.dataset.plan;
        
        if (!planId) {
            console.error('IL Pricing Page: No plan ID found on button');
            showMessage('Erreur: Plan non spécifié', 'error');
            return;
        }
        
        console.log(`IL Pricing Page: Checkout clicked for plan: ${planId}`);
        
        // Set button loading state
        setButtonLoading(button, true);
        
        try {
            // Create checkout session without login verification
            const sessionData = await createCheckoutSessionDirect(planId);
            
            if (sessionData.success && sessionData.session_id) {
                // Redirect to Stripe Checkout
                if (stripe) {
                    const { error } = await stripe.redirectToCheckout({
                        sessionId: sessionData.session_id
                    });
                    
                    if (error) {
                        console.error('IL Pricing Page: Stripe redirect error:', error);
                        showMessage('Erreur lors de la redirection vers le paiement', 'error');
                    }
                } else {
                    // Fallback: redirect to checkout URL if available
                    if (sessionData.checkout_url) {
                        window.location.href = sessionData.checkout_url;
                    } else {
                        throw new Error('Stripe not available and no checkout URL provided');
                    }
                }
            } else {
                throw new Error(sessionData.message || 'Failed to create checkout session');
            }
            
        } catch (error) {
            console.error('IL Pricing Page: Checkout error:', error);
            showMessage('Erreur lors de la création de la session de paiement: ' + error.message, 'error');
        } finally {
            setButtonLoading(button, false);
        }
    }
    
    /**
     * Create checkout session via API
     */
    async function createCheckoutSession(planId) {
        const response = await fetch(`${CONFIG.API_BASE_URL}/stripe/create-checkout`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getUserToken()}`
            },
            body: JSON.stringify({
                plan_id: planId
            })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `HTTP ${response.status}`);
        }
        
        return await response.json();
    }
    
    /**
     * Create checkout session without authentication - DIRECT STRIPE REDIRECT
     */
    async function createCheckoutSessionDirect(planId) {
        const response = await fetch(`${CONFIG.API_BASE_URL}/stripe/create-checkout-direct`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                plan_id: planId,
                allow_guest: true
            })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || `HTTP ${response.status}`);
        }
        
        return await response.json();
    }
    
    /**
     * Check user login status
     */
    async function checkUserLoginStatus() {
        try {
            const response = await fetch(`${CONFIG.API_BASE_URL}/auth/status`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${getUserToken()}`
                }
            });
            
            return response.ok;
        } catch (error) {
            console.warn('IL Pricing Page: Could not check login status:', error);
            return false;
        }
    }
    
    /**
     * Check user status and update UI accordingly
     */
    async function checkUserStatus() {
        try {
            const isLoggedIn = await checkUserLoginStatus();
            
            if (isLoggedIn) {
                // Check if user already has premium
                const premiumStatus = await checkPremiumStatus();
                
                if (premiumStatus.isPremium) {
                    updateUIForPremiumUser(premiumStatus);
                }
            } else {
                updateUIForGuestUser();
            }
        } catch (error) {
            console.warn('IL Pricing Page: Error checking user status:', error);
        }
    }
    
    /**
     * Check premium status
     */
    async function checkPremiumStatus() {
        try {
            const response = await fetch(`${CONFIG.API_BASE_URL}/user/premium-status`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${getUserToken()}`
                }
            });
            
            if (response.ok) {
                return await response.json();
            }
        } catch (error) {
            console.warn('IL Pricing Page: Could not check premium status:', error);
        }
        
        return { isPremium: false };
    }
    
    /**
     * Update UI for premium users
     */
    function updateUIForPremiumUser(premiumStatus) {
        const checkoutButtons = document.querySelectorAll('.il-checkout-button');
        
        checkoutButtons.forEach(button => {
            button.textContent = 'Gérer l\'abonnement';
            button.onclick = function(e) {
                e.preventDefault();
                openCustomerPortal();
            };
        });
        
        // Add premium badge
        addPremiumBadge();
    }
    
    /**
     * Update UI for guest users
     */
    function updateUIForGuestUser() {
        // Add login prompts to buttons
        const checkoutButtons = document.querySelectorAll('.il-checkout-button');
        
        checkoutButtons.forEach(button => {
            const originalText = button.textContent;
            button.title = 'Connexion requise pour s\'abonner';
        });
    }
    
    /**
     * Open Stripe Customer Portal
     */
    async function openCustomerPortal() {
        try {
            const response = await fetch(`${CONFIG.API_BASE_URL}/stripe/customer-portal`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${getUserToken()}`
                }
            });
            
            if (response.ok) {
                const data = await response.json();
                if (data.portal_url) {
                    window.location.href = data.portal_url;
                }
            } else {
                throw new Error('Failed to create customer portal session');
            }
        } catch (error) {
            console.error('IL Pricing Page: Customer portal error:', error);
            showMessage('Erreur lors de l\'ouverture du portail client', 'error');
        }
    }
    
    /**
     * Show login required message
     */
    function showLoginRequired() {
        const message = 'Vous devez être connecté pour vous abonner. Voulez-vous vous connecter maintenant ?';
        
        if (confirm(message)) {
            // Redirect to login page
            const loginUrl = '/wp-login.php?redirect_to=' + encodeURIComponent(window.location.href);
            window.location.href = loginUrl;
        }
    }
    
    /**
     * Add premium badge to page
     */
    function addPremiumBadge() {
        const badge = document.createElement('div');
        badge.className = 'premium-user-badge';
        badge.innerHTML = '👑 Utilisateur Premium';
        badge.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
            z-index: 1000;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        `;
        
        document.body.appendChild(badge);
    }
    
    /**
     * Set button loading state
     */
    function setButtonLoading(button, loading) {
        if (loading) {
            button.disabled = true;
            button.textContent = 'Chargement...';
            button.style.opacity = '0.7';
        } else {
            button.disabled = false;
            button.textContent = button.dataset.originalText;
            button.style.opacity = '1';
        }
    }
    
    /**
     * Show message to user
     */
    function showMessage(message, type = 'info') {
        // Remove existing messages
        const existingMessages = document.querySelectorAll('.il-message');
        existingMessages.forEach(msg => msg.remove());
        
        // Create message element
        const messageEl = document.createElement('div');
        messageEl.className = `il-message il-message-${type}`;
        messageEl.textContent = message;
        
        // Style the message
        messageEl.style.cssText = `
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            padding: 12px 24px;
            border-radius: 6px;
            color: white;
            font-weight: 500;
            z-index: 10000;
            max-width: 400px;
            text-align: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transition: all 0.3s ease;
        `;
        
        // Set background color based on type
        switch (type) {
            case 'success':
                messageEl.style.backgroundColor = '#10b981';
                break;
            case 'error':
                messageEl.style.backgroundColor = '#ef4444';
                break;
            case 'warning':
                messageEl.style.backgroundColor = '#f59e0b';
                break;
            default:
                messageEl.style.backgroundColor = '#3b82f6';
        }
        
        // Add to page
        document.body.appendChild(messageEl);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            messageEl.style.opacity = '0';
            messageEl.style.transform = 'translateX(-50%) translateY(-20px)';
            setTimeout(() => {
                if (messageEl.parentNode) {
                    messageEl.remove();
                }
            }, 300);
        }, 5000);
    }
    
    /**
     * Get user token from localStorage or cookies
     */
    function getUserToken() {
        // Try localStorage first
        let token = localStorage.getItem('il_auth_token');
        
        if (!token) {
            // Try cookies as fallback
            const cookies = document.cookie.split(';');
            for (let cookie of cookies) {
                const [name, value] = cookie.trim().split('=');
                if (name === 'il_auth_token') {
                    token = value;
                    break;
                }
            }
        }
        
        return token || '';
    }
    
    // Expose some functions globally for debugging
    window.ILPricing = {
        createCheckoutSession,
        checkUserLoginStatus,
        checkPremiumStatus,
        openCustomerPortal
    };
    
})();

