/**
 * Stripe integration for IL Premium
 */
(function($) {
    'use strict';
    
    // Initialize Stripe
    var stripe;
    
    $(document).ready(function() {
        if (typeof il_stripe_params !== 'undefined') {
            stripe = Stripe(il_stripe_params.publishable_key);
            
            // Checkout button click
            $('#il-checkout-button').on('click', function(e) {
                e.preventDefault();
                
                var $button = $(this);
                var planId = $button.data('plan') || 'monthly';
                
                $button.prop('disabled', true).text('Processing...');
                $('#il-checkout-message').html('');
                
                // Create checkout session
                $.ajax({
                    type: 'POST',
                    url: il_stripe_params.ajax_url,
                    data: {
                        action: 'il_create_checkout_session',
                        plan_id: planId,
                        nonce: il_stripe_params.nonce
                    },
                    success: function(response) {
                        if (response.success && response.data && response.data.session_id) {
                            // Redirect to Stripe Checkout
                            stripe.redirectToCheckout({
                                sessionId: response.data.session_id
                            }).then(function(result) {
                                if (result.error) {
                                    $('#il-checkout-message').html('<div class="error">' + result.error.message + '</div>');
                                    $button.prop('disabled', false).text('Try Again');
                                }
                            });
                        } else {
                            var errorMessage = response.data && response.data.message ? response.data.message : 'An error occurred. Please try again.';
                            $('#il-checkout-message').html('<div class="error">' + errorMessage + '</div>');
                            $button.prop('disabled', false).text('Try Again');
                        }
                    },
                    error: function() {
                        $('#il-checkout-message').html('<div class="error">Connection error. Please try again.</div>');
                        $button.prop('disabled', false).text('Try Again');
                    }
                });
            });
            
            // Customer portal link
            $('.il-customer-portal').on('click', function(e) {
                e.preventDefault();
                
                var $link = $(this);
                $link.text('Loading...');
                
                // Create customer portal session
                $.ajax({
                    type: 'POST',
                    url: il_stripe_params.ajax_url,
                    data: {
                        action: 'il_create_customer_portal',
                        nonce: il_stripe_params.nonce
                    },
                    success: function(response) {
                        if (response.success && response.data && response.data.portal_url) {
                            window.location.href = response.data.portal_url;
                        } else {
                            var errorMessage = response.data && response.data.message ? response.data.message : 'An error occurred. Please try again.';
                            alert(errorMessage);
                            $link.text('Manage Subscription');
                        }
                    },
                    error: function() {
                        alert('Connection error. Please try again.');
                        $link.text('Manage Subscription');
                    }
                });
            });
        }
    });
    
})(jQuery);

